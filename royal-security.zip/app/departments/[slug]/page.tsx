import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import SplineBackground from "@/components/SplineBackground";
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { departments, getDepartment } from "@/lib/departments";
import { createClient } from "@/utils/supabase/server";

export const revalidate = 300;

// Pre-render all 8 known department slugs at build time (SSG per Section 7.1)
export function generateStaticParams() {
  return departments.map((d) => ({ slug: d.slug }));
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const dept = getDepartment(slug);
  if (!dept) return { title: "Department Not Found" };
  return {
    title: dept.name,
    description: dept.rationale,
  };
}

type RelatedWriteup = {
  id: string;
  title: string;
  slug: string;
  challenge_name: string;
  difficulty: string;
  created_at: string;
};

async function getRelatedWriteups(departmentSlug: string): Promise<RelatedWriteup[]> {
  const supabase = await createClient();
  const { data, error } = await supabase
    .from("writeups")
    .select("id, title, slug, challenge_name, difficulty, created_at")
    .eq("department_slug", departmentSlug)
    .eq("is_gated", false) // same public-visibility rule as /writeups
    .order("created_at", { ascending: false })
    .limit(3);

  if (error || !data) return [];
  return data as RelatedWriteup[];
}

export default async function DepartmentPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const dept = getDepartment(slug);

  // Unknown slugs (e.g. leftover "purple-team" links) now 404 instead of rendering
  // a fake department with a slug-derived title.
  if (!dept) notFound();

  const relatedWriteups = await getRelatedWriteups(slug);

  return (
    <main className="relative min-h-screen">
      {/* Background (global Navbar is mounted once in app/layout.tsx) */}
      <SplineBackground />

      {/* Hero Section */}
      <div className="relative z-10 flex flex-col items-center justify-center min-h-[50vh] px-4 text-center">
        <Badge style={{ backgroundColor: dept.hex, color: "#0B1120" }} className="mb-4">
          {dept.hex}
        </Badge>
        <h1 className="max-w-4xl text-5xl font-extrabold tracking-tight text-white sm:text-7xl">
          <span style={{ color: dept.hex }} className="transition-colors duration-500">
            {dept.name}
          </span>
        </h1>
        <p className="mt-6 max-w-2xl text-lg text-muted-foreground">{dept.rationale}</p>
      </div>

      {/* Content Section */}
      <div className="relative z-10 container mx-auto grid gap-6 px-4 pb-12 sm:grid-cols-2">
        <Card className="border-gray-800 bg-card/50 backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="text-white">Arsenal</CardTitle>
            <CardDescription>Software and frameworks used by this division.</CardDescription>
          </CardHeader>
          <CardContent className="flex flex-wrap gap-2">
            {dept.arsenal.map((tool) => (
              <Badge key={tool} variant="outline">
                {tool}
              </Badge>
            ))}
          </CardContent>
        </Card>

        <Card className="border-gray-800 bg-card/50 backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="text-white">Learning Path</CardTitle>
            <CardDescription>
              Curriculum and CTF modules for the {dept.name} track are managed in the Learner
              Portal.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Link
              href="/portal/learner"
              className="inline-block rounded-md px-4 py-2 text-sm font-semibold text-black transition-opacity hover:opacity-90"
              style={{ backgroundColor: dept.hex }}
            >
              Enter Learner Portal
            </Link>
          </CardContent>
        </Card>
      </div>

      {/* Related Writeups — real, department-specific content, not static text */}
      <div className="relative z-10 container mx-auto px-4 pb-24">
        <h2 className="mb-6 text-2xl font-bold text-white">
          Recent {dept.name} Writeups
        </h2>
        {relatedWriteups.length === 0 ? (
          <p className="text-sm text-muted-foreground">
            No public writeups tagged for this department yet. Check back soon, or browse{" "}
            <Link href="/writeups" className="underline">
              all writeups
            </Link>
            .
          </p>
        ) : (
          <div className="grid gap-6 sm:grid-cols-3">
            {relatedWriteups.map((w) => (
              <Link key={w.id} href={`/writeups/${w.slug}`}>
                <Card
                  className="h-full border-gray-800 bg-card/50 backdrop-blur-sm transition-colors"
                  style={{ borderColor: `${dept.hex}55` }}
                >
                  <CardHeader>
                    <Badge variant="outline" className="w-fit">
                      {w.difficulty}
                    </Badge>
                    <CardTitle className="text-white">{w.challenge_name}</CardTitle>
                    <CardDescription>{w.title}</CardDescription>
                  </CardHeader>
                </Card>
              </Link>
            ))}
          </div>
        )}
      </div>
    </main>
  );
}