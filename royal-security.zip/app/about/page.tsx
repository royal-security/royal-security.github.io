import type { Metadata } from "next";
import { createClient } from "@/utils/supabase/server";
import { Card, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";

export const metadata: Metadata = {
  title: "About",
  description: "The mission, values, and people behind Royal Security.",
};

type TeamMember = {
  id: string;
  name: string;
  role: string;
  department: string | null;
};

// Public marketing page: SSG-friendly, revalidates periodically rather than on every request.
export const revalidate = 3600;

async function getTeam(): Promise<TeamMember[]> {
  const supabase = await createClient();
  const { data, error } = await supabase
    .from("team_members")
    .select("id, name, role, department")
    .order("sort_order", { ascending: true });

  if (error || !data) return [];
  return data as TeamMember[];
}

export default async function AboutPage() {
  const team = await getTeam();

  return (
    <main className="container mx-auto px-4 py-24">
      <h1 className="text-4xl font-extrabold tracking-tight text-white sm:text-6xl">
        About Royal Security
      </h1>

      <section className="mt-10 max-w-3xl space-y-4 text-muted-foreground">
        <p>
          Royal Security is a member-driven organization dedicated to advancing offensive and
          defensive cybersecurity practice through hands-on training, competitive research, and
          real-world engagements for enterprise clients.
        </p>
        <p>
          What began as a small group of students trading writeups grew into a structured
          organization spanning eight operational departments, a formal client-facing audit
          practice, and a continuously updated learner curriculum.
        </p>
      </section>

      <section className="mt-16">
        <h2 className="text-2xl font-bold text-white">Core Values</h2>
        <div className="mt-6 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {["Ethics", "Learning", "Teamwork", "Integrity"].map((value) => (
            <Card key={value} className="border-gray-800 bg-card/50">
              <CardHeader>
                <CardTitle className="text-white">{value}</CardTitle>
              </CardHeader>
            </Card>
          ))}
        </div>
      </section>

      <section className="mt-16">
        <h2 className="text-2xl font-bold text-white">Organization</h2>
        {team.length === 0 ? (
          <p className="mt-4 text-sm text-muted-foreground">
            Team roster is managed via the admin dashboard and will appear here once populated.
          </p>
        ) : (
          <div className="mt-6 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {team.map((member) => (
              <Card key={member.id} className="border-gray-800 bg-card/50">
                <CardHeader>
                  <CardTitle className="text-white">{member.name}</CardTitle>
                  <CardDescription>
                    {member.role}
                    {member.department ? ` · ${member.department}` : ""}
                  </CardDescription>
                </CardHeader>
              </Card>
            ))}
          </div>
        )}
      </section>
    </main>
  );
}
