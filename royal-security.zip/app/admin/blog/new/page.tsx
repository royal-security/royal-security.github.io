import { BlogForm } from "@/components/admin/BlogForm";
import { requirePermissionPage } from "@/lib/roles-page";
import { PERMISSIONS } from "@/lib/roles";

export default async function NewBlogPostPage() {
  await requirePermissionPage(PERMISSIONS.BLOG_WRITE);
  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">New Blog Post</h1>
      <BlogForm />
    </div>
  );
}
