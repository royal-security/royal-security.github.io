import { Resend } from 'resend';

const resend = new Resend(process.env.RESEND_API_KEY);

export const sendNotification = async (subject: string, text: string) => {
  if (!process.env.RESEND_API_KEY) return;
  try {
    await resend.emails.send({
      from: 'Royal Security <onboarding@resend.dev>',
      to: 'delivered@resend.dev',
      subject,
      text,
    });
  } catch (error) {
    console.error('Email error:', error);
  }
};
