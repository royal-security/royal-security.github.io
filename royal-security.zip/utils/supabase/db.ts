import { createClient } from "@/utils/supabase/server";
import { createAdminClient } from "@/utils/supabase/admin";

/**
 * Database handle for server components/pages in the admin console and
 * portals. Prefers the service-role client (bypasses RLS so admins see
 * every row, including gated writeups and cross-org data); falls back to
 * the session client when SUPABASE_SERVICE_ROLE_KEY is not configured.
 * Server-only — never import into client components.
 */
export async function getDbClient() {
  return createAdminClient() ?? (await createClient());
}
