"use client";

import { useRouter } from "next/navigation";
import { createWriteup, updateWriteup } from "@/app/actions";

const DIFFICULTIES = ["Beginner", "Intermediate", "Advanced"];
const inputClass = "p-2 rounded bg-gray-800 border border-gray-700 text-white w-full";

type Writeup = {
  id: string;
  title: string;
  slug: string;
  challenge_name: string;
  difficulty: string;
  category: string;
  content: string;
  is_gated: boolean;
  department?: string | null;
};

export function WriteupForm({
  writeup,
  lockedDepartment,
}: {
  writeup?: Writeup;
  /** Non-null when the signed-in user is a dept_lead: department is fixed to
   * their own and rendered read-only. Null for founder, who can set it freely. */
  lockedDepartment?: string | null;
}) {
  const router = useRouter();
  const action = writeup ? updateWriteup : createWriteup;

  async function handleSubmit(formData: FormData) {
    await action(formData);
    router.push("/admin/writeups");
  }

  return (
    <form action={handleSubmit} className="grid gap-4 max-w-2xl">
      {writeup && <input type="hidden" name="id" value={writeup.id} />}
      <div>
        <label className="text-sm text-gray-400 mb-1 block">Title</label>
        <input name="title" defaultValue={writeup?.title} required className={inputClass} />
      </div>
      <div>
        <label className="text-sm text-gray-400 mb-1 block">Slug</label>
        <input name="slug" defaultValue={writeup?.slug} required className={inputClass} />
      </div>
      <div>
        <label className="text-sm text-gray-400 mb-1 block">Challenge Name</label>
        <input
          name="challenge_name"
          defaultValue={writeup?.challenge_name}
          required
          className={inputClass}
        />
      </div>
      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="text-sm text-gray-400 mb-1 block">Difficulty</label>
          <select
            name="difficulty"
            defaultValue={writeup?.difficulty ?? DIFFICULTIES[0]}
            required
            className={inputClass}
          >
            {DIFFICULTIES.map((d) => (
              <option key={d} value={d}>
                {d}
              </option>
            ))}
          </select>
        </div>
        <div>
          <label className="text-sm text-gray-400 mb-1 block">Category</label>
          <input name="category" defaultValue={writeup?.category} required className={inputClass} />
        </div>
      </div>
      <div>
        <label className="text-sm text-gray-400 mb-1 block">Content</label>
        <textarea
          name="content"
          defaultValue={writeup?.content}
          required
          className={`${inputClass} h-64 font-mono text-sm`}
        />
      </div>
      <div>
        <label className="text-sm text-gray-400 mb-1 block">Department</label>
        {lockedDepartment !== undefined && lockedDepartment !== null ? (
          <>
            <input value={lockedDepartment} disabled className={`${inputClass} opacity-60`} />
            <p className="text-xs text-gray-500 mt-1">
              Locked to your department — dept_leads can only publish under their own.
            </p>
          </>
        ) : (
          <input
            name="department"
            defaultValue={writeup?.department ?? ""}
            placeholder="e.g. red-team (optional)"
            className={inputClass}
          />
        )}
      </div>
      <label className="flex items-center gap-2 text-sm text-gray-300">
        <input type="checkbox" name="is_gated" defaultChecked={writeup?.is_gated} />
        Learner-Portal-only (gated) — hides from the public /writeups page
      </label>
      <button
        type="submit"
        className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 rounded font-semibold transition w-fit"
      >
        {writeup ? "Save Changes" : "Publish Writeup"}
      </button>
    </form>
  );
}
