import type { MetadataRoute } from "next";
import { departments } from "@/lib/departments";
import { createClient } from "@/utils/supabase/server";

// Set this in your .env / .env.local — see NEXT_PUBLIC_SITE_URL in the deployment notes.
const BASE_URL = process.env.NEXT_PUBLIC_SITE_URL ?? "https://royalsecurity.example";

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const staticRoutes: MetadataRoute.Sitemap = [
    "",
    "/about",
    "/join",
    "/contact",
    "/privacy",
    "/code-of-conduct",
    "/departments",
    "/blog",
    "/writeups",
  ].map((path) => ({
    url: `${BASE_URL}${path}`,
    lastModified: new Date(),
    changeFrequency: "weekly",
    priority: path === "" ? 1 : 0.7,
  }));

  const departmentRoutes: MetadataRoute.Sitemap = departments.map((d) => ({
    url: `${BASE_URL}/departments/${d.slug}`,
    lastModified: new Date(),
    changeFrequency: "monthly",
    priority: 0.6,
  }));

  let contentRoutes: MetadataRoute.Sitemap = [];
  try {
    const supabase = await createClient();
    const [{ data: posts }, { data: writeups }] = await Promise.all([
      supabase.from("blog_posts").select("slug, created_at"),
      supabase.from("writeups").select("slug, created_at"),
    ]);

    contentRoutes = [
      ...(posts ?? []).map((p) => ({
        url: `${BASE_URL}/blog/${p.slug}`,
        lastModified: new Date(p.created_at),
        changeFrequency: "monthly" as const,
        priority: 0.5,
      })),
      ...(writeups ?? []).map((w) => ({
        url: `${BASE_URL}/writeups/${w.slug}`,
        lastModified: new Date(w.created_at),
        changeFrequency: "monthly" as const,
        priority: 0.5,
      })),
    ];
  } catch {
    // Supabase not reachable at build time — sitemap still returns static + department routes.
  }

  return [...staticRoutes, ...departmentRoutes, ...contentRoutes];
}
