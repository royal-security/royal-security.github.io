'use client';
import { useEffect, useRef } from 'react';
import Spline from '@splinetool/react-spline';

export default function SplineBackground() {
  const splineRef = useRef<any>(null);

  function onLoad(splineApp: any) {
    splineRef.current = splineApp;
  }

  useEffect(() => {
    const handleScroll = () => {
      if (splineRef.current && typeof splineRef.current.setVariable === 'function') {
        const progress = window.scrollY / (document.body.scrollHeight - window.innerHeight);
        splineRef.current.setVariable('scrollProgress', progress * 100);
      }
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <div className="fixed inset-0 -z-10 bg-[#0B1120]">
      <Spline scene="https://prod.spline.design/6Wq1Q7YGyM-iab9i/scene.splinecode" onLoad={onLoad} />
    </div>
  );
}