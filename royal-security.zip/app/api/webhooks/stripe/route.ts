import { headers } from 'next/headers';
import { NextResponse } from 'next/server';
import Stripe from 'stripe';

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || '', {
  apiVersion: '2026-07-29.dahlia' as any
});

export async function POST(req: Request) {
  const body = await req.text();
  const headersList = await headers();
  const signature = headersList.get('Stripe-Signature') as string;

  let event: Stripe.Event;

  try {
    event = stripe.webhooks.constructEvent(body, signature, process.env.STRIPE_WEBHOOK_SECRET || '');
  } catch (error: any) {
    return new NextResponse('Webhook Error: ' + error.message, { status: 400 });
  }

  if (event.type === 'checkout.session.completed') {
    console.log('Payment successful for session:', (event.data.object as any).id);
  }

  return new NextResponse('Webhook received', { status: 200 });
}