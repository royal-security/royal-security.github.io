import Link from "next/link";
import { createAdminClient } from "@/utils/supabase/admin";
import { deleteWriteup } from "@/app/actions";
import { requirePermissionPage } from "@/lib/roles-page";
import { PERMISSIONS } from "@/lib/roles";

export const dynamic = "force-dynamic";

async function getWriteups(department: string | null) {
  const supabase = createAdminClient();
  if (!supabase) return [];
  let query = supabase
    .from("writeups")
    .select("id, title, difficulty, category, is_gated, department, created_at")
    .order("created_at", { ascending: false });
  if (department) query = query.eq("department", department);
  const { data } = await query;
  return data ?? [];
}

export default async function AdminWriteupsPage() {
  const claims = await requirePermissionPage(PERMISSIONS.WRITEUPS_WRITE);
  const writeups = await getWriteups(claims.role === "dept_lead" ? claims.department : null);

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold">Writeups</h1>
        <Link
          href="/admin/writeups/new"
          className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 rounded font-semibold text-sm transition"
        >
          + New Writeup
        </Link>
      </div>

      <div className="rounded-lg border border-gray-800 overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-gray-900 text-gray-400">
            <tr>
              <th className="text-left p-3">Title</th>
              <th className="text-left p-3">Difficulty</th>
              <th className="text-left p-3">Category</th>
              <th className="text-left p-3">Department</th>
              <th className="text-left p-3">Visibility</th>
              <th className="text-right p-3">Actions</th>
            </tr>
          </thead>
          <tbody>
            {writeups.map((w) => (
              <tr key={w.id} className="border-t border-gray-800">
                <td className="p-3">{w.title}</td>
                <td className="p-3 text-gray-400">{w.difficulty}</td>
                <td className="p-3 text-gray-400">{w.category}</td>
                <td className="p-3 text-gray-400">{w.department ?? "—"}</td>
                <td className="p-3">
                  {w.is_gated ? (
                    <span className="text-amber-400">Gated (Portal only)</span>
                  ) : (
                    <span className="text-emerald-400">Public</span>
                  )}
                </td>
                <td className="p-3 text-right space-x-3">
                  <Link href={`/admin/writeups/${w.id}`} className="text-blue-400 hover:underline">
                    Edit
                  </Link>
                  <form action={deleteWriteup} className="inline">
                    <input type="hidden" name="id" value={w.id} />
                    <button type="submit" className="text-red-400 hover:underline">
                      Delete
                    </button>
                  </form>
                </td>
              </tr>
            ))}
            {writeups.length === 0 && (
              <tr>
                <td colSpan={6} className="p-6 text-center text-gray-500">
                  No writeups yet.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
