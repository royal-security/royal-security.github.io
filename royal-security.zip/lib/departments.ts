// Single source of truth for the Dynamic Departmental Chromatic Matrix (Blueprint Section 5.2)
// Every hex value below is taken directly from the plan. ThemeProvider, Navbar, the /departments
// hub, and the /departments/[slug] page all import from here so the 8 departments and their
// colors never drift out of sync with each other.

export type Department = {
  name: string;
  slug: string;
  hex: string;
  hsl: string; // "H S% L%" — pre-converted for the --department-accent CSS variable
  rationale: string;
  arsenal: string[];
};

export const departments: Department[] = [
  {
    name: "Red Team",
    slug: "red-team",
    hex: "#FF3B30",
    hsl: "3.2 100% 59.4%",
    rationale: "Offensive security and penetration testing; an aggressive, alert crimson.",
    arsenal: ["Cobalt Strike", "Metasploit", "Burp Suite Pro", "Nmap"],
  },
  {
    name: "Blue Team",
    slug: "blue-team",
    hex: "#007AFF",
    hsl: "211.3 100% 50%",
    rationale: "Defensive operations and incident response; a protective, stable azure.",
    arsenal: ["Splunk", "Wazuh", "Suricata", "Velociraptor"],
  },
  {
    name: "CTF & Research",
    slug: "ctf-research",
    hex: "#AF52DE",
    hsl: "279.9 68% 59.6%",
    rationale: "Academic research and cryptography; an analytical, deep purple.",
    arsenal: ["Ghidra", "IDA Pro", "SageMath", "CyberChef"],
  },
  {
    name: "Web Security",
    slug: "web-security",
    hex: "#34C759",
    hsl: "135.1 58.6% 49.2%",
    rationale: "Application layer defense; a validation and success-oriented emerald.",
    arsenal: ["Burp Suite", "OWASP ZAP", "sqlmap", "Postman"],
  },
  {
    name: "Network Security",
    slug: "network-security",
    hex: "#FF9500",
    hsl: "35.1 100% 50%",
    rationale: "Infrastructure routing and packet analysis; a caution and alert orange.",
    arsenal: ["Wireshark", "Nmap", "tcpdump", "pfSense"],
  },
  {
    name: "OSINT",
    slug: "osint",
    hex: "#5AC8FA",
    hsl: "198.8 94.1% 66.7%",
    rationale: "Open-source intelligence; an expansive, observational sky blue.",
    arsenal: ["Maltego", "SpiderFoot", "Shodan", "theHarvester"],
  },
  {
    name: "Training",
    slug: "training",
    hex: "#FFCC00",
    hsl: "48 100% 50%",
    rationale: "Learner portal integration and onboarding; an illuminated, guiding yellow.",
    arsenal: ["TryHackMe", "HackTheBox", "CTFd", "Custom LMS"],
  },
  {
    name: "Media & Content",
    slug: "media",
    hex: "#FF2D55",
    hsl: "348.6 100% 58.8%",
    rationale: "Brand outreach and publications; a highly energetic and engaging pink.",
    arsenal: ["Figma", "Premiere Pro", "OBS Studio", "Notion"],
  },
];

// Default accent when no department is active (matches the existing globals.css emerald default)
export const DEFAULT_ACCENT_HSL = "142.1 76.2% 36.3%";

export function getDepartment(slug: string): Department | undefined {
  return departments.find((d) => d.slug === slug);
}
