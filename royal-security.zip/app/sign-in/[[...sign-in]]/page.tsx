import { SignIn } from '@clerk/nextjs'

export default async function Page({
  searchParams,
}: {
  searchParams: Promise<{ redirect_url?: string }>;
}) {
  const { redirect_url } = await searchParams;

  return (
    <div className="flex justify-center items-center min-h-screen">
      <SignIn fallbackRedirectUrl={redirect_url ?? "/"} />
    </div>
  )
}