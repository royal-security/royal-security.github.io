"use client";

import { usePathname } from "next/navigation";
import Navbar from "./Navbar";

const HIDE_ON_PREFIXES = ["/admin", "/portal"];

export function ConditionalNavbar() {
  const pathname = usePathname();
  const shouldHide = HIDE_ON_PREFIXES.some((prefix) => pathname?.startsWith(prefix));

  if (shouldHide) return null;
  return <Navbar />;
}