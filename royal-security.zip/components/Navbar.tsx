"use client";

import Link from "next/link";
import { SignInButton, UserButton, OrganizationSwitcher, useAuth } from "@clerk/nextjs";
import { useState, useEffect } from "react";
import { useTheme } from "./ThemeProvider";
import { departments } from "@/lib/departments";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

export default function Navbar() {
  const { department } = useTheme();
  // Using the hook directly bypasses the Turbopack export bug
  const { userId } = useAuth();
const [isClient, setIsClient] = useState(false);

useEffect(() => {
  if (userId) {
    fetch("/api/secure/client-status")
      .then((res) => res.json())
      .then((data) => setIsClient(data.isClient))
      .catch(() => setIsClient(false));
  } else {
    setIsClient(false);
  }
}, [userId]);

  return (
    <nav className="sticky top-0 z-50 w-full border-b border-white/10 bg-background/80 backdrop-blur-md supports-[backdrop-filter]:bg-background/60">
      <div className="container mx-auto flex h-16 items-center justify-between px-4">
        <div className="flex items-center gap-6">
          <Link href="/" className="flex items-center space-x-2">
            <span className="text-xl font-bold tracking-tighter text-white">
              ROYAL<span className="text-department transition-colors duration-500">SEC</span>
            </span>
          </Link>

          {/* Primary Navigation */}
          <div className="hidden md:flex items-center gap-4 text-sm font-medium text-muted-foreground">
            <Link href="/about" className="hover:text-white transition-colors">About</Link>

            {/* All 8 departments, driven by lib/departments.ts */}
            <DropdownMenu>
              <DropdownMenuTrigger className="hover:text-white transition-colors outline-none">
                Departments
              </DropdownMenuTrigger>
              <DropdownMenuContent align="start">
                {departments.map((d) => (
                  // This UI kit is built on @base-ui/react, which uses a `render` prop
                  // instead of Radix's `asChild` — passing asChild here would silently
                  // no-op and the Link would fail to render as the menu item.
                  <DropdownMenuItem key={d.slug} render={<Link href={`/departments/${d.slug}`} />}>
                    {d.name}
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>

            <Link href="/blog" className="hover:text-white transition-colors">Blog</Link>
            <Link href="/writeups" className="hover:text-white transition-colors">Writeups</Link>
            <Link href="/join" className="hover:text-white transition-colors">Join</Link>
            <Link href="/contact" className="hover:text-white transition-colors">Contact</Link>
          </div>
        </div>

        <div className="flex items-center gap-4">
          {!userId ? (
            /* Unauthenticated State */
            <div className="rounded-md bg-white px-4 py-2 text-sm font-medium text-black hover:bg-gray-200 transition-colors">
              <SignInButton mode="modal" />
            </div>
          ) : (
            /* Authenticated State */
            <>
              {isClient && (
  <Link href="/portal/client" className="text-sm font-medium text-muted-foreground hover:text-white mr-2">
    Client Portal
  </Link>
)}
<Link href="/portal/learner" className="text-sm font-medium text-muted-foreground hover:text-white mr-2">
  Learner Portal
</Link>
              <OrganizationSwitcher
                appearance={{
                  elements: {
                    organizationSwitcherTrigger: "text-white",
                  },
                }}
              />
              {/* Note: sign-out redirect is now configured on <ClerkProvider afterSignOutUrl="/">
                  in app/layout.tsx — UserButton no longer accepts afterSignOutUrl in this
                  Clerk version. */}
              <UserButton
                appearance={{
                  elements: {
                    userButtonAvatarBox: "w-8 h-8 rounded-md border border-gray-700",
                  },
                }}
              />
            </>
          )}
        </div>
      </div>
    </nav>
  );
}
