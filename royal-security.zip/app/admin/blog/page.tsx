import Link from "next/link";
import { createAdminClient } from "@/utils/supabase/admin";
import { deleteBlogPost } from "@/app/actions";
import { requirePermissionPage } from "@/lib/roles-page";
import { PERMISSIONS } from "@/lib/roles";

export const dynamic = "force-dynamic";

async function getPosts() {
  const supabase = createAdminClient();
  if (!supabase) return [];
  const { data } = await supabase
    .from("blog_posts")
    .select("id, title, slug, category, created_at")
    .order("created_at", { ascending: false });
  return data ?? [];
}

export default async function AdminBlogPage() {
  await requirePermissionPage(PERMISSIONS.BLOG_WRITE);
  const posts = await getPosts();

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold">Blog Posts</h1>
        <Link
          href="/admin/blog/new"
          className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 rounded font-semibold text-sm transition"
        >
          + New Post
        </Link>
      </div>

      <div className="rounded-lg border border-gray-800 overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-gray-900 text-gray-400">
            <tr>
              <th className="text-left p-3">Title</th>
              <th className="text-left p-3">Category</th>
              <th className="text-left p-3">Created</th>
              <th className="text-right p-3">Actions</th>
            </tr>
          </thead>
          <tbody>
            {posts.map((post) => (
              <tr key={post.id} className="border-t border-gray-800">
                <td className="p-3">{post.title}</td>
                <td className="p-3 text-gray-400">{post.category}</td>
                <td className="p-3 text-gray-400">
                  {new Date(post.created_at).toLocaleDateString()}
                </td>
                <td className="p-3 text-right space-x-3">
                  <Link href={`/admin/blog/${post.id}`} className="text-blue-400 hover:underline">
                    Edit
                  </Link>
                  <form action={deleteBlogPost} className="inline">
                    <input type="hidden" name="id" value={post.id} />
                    <button type="submit" className="text-red-400 hover:underline">
                      Delete
                    </button>
                  </form>
                </td>
              </tr>
            ))}
            {posts.length === 0 && (
              <tr>
                <td colSpan={4} className="p-6 text-center text-gray-500">
                  No blog posts yet.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
