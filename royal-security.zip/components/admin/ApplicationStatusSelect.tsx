"use client";

import { useTransition } from "react";
import { updateApplicationStatus } from "@/app/actions";

const STATUSES = ["New", "Reviewing", "Accepted", "Rejected"];

const COLORS: Record<string, string> = {
  New: "text-blue-400",
  Reviewing: "text-amber-400",
  Accepted: "text-emerald-400",
  Rejected: "text-red-400",
};

export function ApplicationStatusSelect({ id, status }: { id: string; status: string }) {
  const [isPending, startTransition] = useTransition();

  return (
    <select
      defaultValue={status}
      disabled={isPending}
      onChange={(e) => {
        const formData = new FormData();
        formData.set("id", id);
        formData.set("status", e.target.value);
        startTransition(() => {
          updateApplicationStatus(formData);
        });
      }}
      className={`p-1.5 rounded bg-gray-800 border border-gray-700 text-sm ${COLORS[status] ?? ""}`}
    >
      {STATUSES.map((s) => (
        <option key={s} value={s}>
          {s}
        </option>
      ))}
    </select>
  );
}
