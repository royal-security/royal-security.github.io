// Phase 12 — operational notifications.
// Uses the Resend REST API (no extra dependency) for transactional email
// and/or a generic webhook (Slack/Discord). Everything is opt-in: when
// RESEND_API_KEY / ADMIN_NOTIFY_EMAIL / NOTIFY_WEBHOOK_URL are not set,
// notifications are a silent no-op so the app never breaks without them.

export type NotificationPayload = {
  subject: string;
  text: string;
  html?: string;
};

function escapeHtml(value: string): string {
  return value
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

export async function notifyAdmins(payload: NotificationPayload): Promise<void> {
  const apiKey = process.env.RESEND_API_KEY;
  const to = process.env.ADMIN_NOTIFY_EMAIL;
  const webhookUrl = process.env.NOTIFY_WEBHOOK_URL;

  if (!apiKey && !webhookUrl) return;

  const html =
    payload.html ??
    `<p>${escapeHtml(payload.text).replace(/\n/g, "<br/>")}</p>`;

  if (apiKey && to) {
    try {
      await fetch("https://api.resend.com/emails", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${apiKey}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          from: process.env.RESEND_FROM_EMAIL ?? "Royal Security <onboarding@resend.dev>",
          to,
          subject: payload.subject,
          text: payload.text,
          html,
        }),
      });
    } catch {
      // best-effort
    }
  }

  if (webhookUrl) {
    try {
      await fetch(webhookUrl, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          text: `[Royal Security] ${payload.subject}\n\n${payload.text}`,
        }),
      });
    } catch {
      // best-effort
    }
  }
}
