import Link from "next/link";
import { auth } from "@clerk/nextjs/server";
import { redirect } from "next/navigation";
import { normalizeRole, ROLE_LABELS } from "@/lib/roles";
import { NAV } from "./layout";

export default async function AdminPage() {
  const { userId, sessionClaims } = await auth();
  const metadata = (sessionClaims?.metadata ?? {}) as { role?: string };
  const role = normalizeRole(metadata.role);

  // The layout above already redirects unauthenticated/"member" users away
  // from every /admin/* route, so this is a defense-in-depth check, not
  // the only line of defense.
  if (!userId) redirect("/sign-in");
  if (role === "member") redirect("/portal/learner");

  const accessible = NAV.filter((item) => item.roles.includes(role));

  return (
    <div>
      <h1 className="text-3xl font-bold mb-2">Admin Dashboard</h1>
      <p className="text-gray-400 mb-8">
        Signed in as <span className="text-white font-medium">{ROLE_LABELS[role]}</span>
      </p>

      <div className="grid gap-4 sm:grid-cols-2">
        {accessible.map((item) => (
          <Link
            key={item.href}
            href={item.href}
            className="p-5 rounded-lg border border-gray-800 bg-gray-900/50 hover:border-emerald-600 transition"
          >
            <div className="font-semibold text-white">{item.label}</div>
          </Link>
        ))}
      </div>

      {accessible.length === 0 && (
        <p className="text-sm text-gray-500">
          Your role doesn&apos;t have access to any admin sections yet. Contact a founder to be
          granted permissions.
        </p>
      )}
    </div>
  );
}
