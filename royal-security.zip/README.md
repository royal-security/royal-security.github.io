# Phase 2 continued — Phase 12, 13.1, 14, 15 delivery

Everything here is additive to what's already in your project. Nothing in
this zip overwrites a working file except `app/admin/layout.tsx` (one new
nav entry) — everything else is either a brand-new file or a documented
find/replace patch you apply by hand (`docs/PATCH_*.md`).

All commands assume:
```cmd
cd F:\Royal-enterprise\royal-security
```

## 1. Install the new dependencies

```cmd
npm install resend @axe-core/playwright
npm install -D vitest @playwright/test
npx playwright install --with-deps chromium
```

## 2. Copy the new files in

From wherever you extracted this delivery:

```cmd
xcopy /E /Y "path\to\delivery\lib" "F:\Royal-enterprise\royal-security\lib"
xcopy /E /Y "path\to\delivery\app" "F:\Royal-enterprise\royal-security\app"
xcopy /E /Y "path\to\delivery\e2e" "F:\Royal-enterprise\royal-security\e2e"
xcopy /E /Y "path\to\delivery\.github" "F:\Royal-enterprise\royal-security\.github"
xcopy /E /Y "path\to\delivery\public" "F:\Royal-enterprise\royal-security\public"
copy "path\to\delivery\vitest.config.ts" "F:\Royal-enterprise\royal-security\"
copy "path\to\delivery\playwright.config.ts" "F:\Royal-enterprise\royal-security\"
```

`docs/PATCH_*.md` and `docs/design-tokens.md` are reference, not code —
copy them into your `docs\` folder too if you want them kept with the rest
of your Phase 13 docs, but nothing depends on their location.

**Note on `app/admin/layout.tsx`:** this delivery's copy already has your
full real nav array plus the one new "Audit Log" entry — it's not a stub. If
you've changed this file since the export you sent me, diff before
overwriting.

## 3. Apply the three patches

Open each doc and make the described find/replace edits by hand — they're
small and I didn't want to silently rewrite `app/actions.ts`,
`components/Navbar.tsx`, or `package.json` wholesale:

1. `docs/PATCH_actions_ts_phase12.md` — wires email notifications into
   `submitVulnerabilityReport`, `submitApplication`, `submitContactMessage`
2. `docs/PATCH_navbar_logo.md` — swaps the text-only wordmark for the new
   `public/logo.svg` + wordmark
3. `docs/PATCH_package_json_scripts.md` — adds `test` / `test:watch` /
   `test:e2e` npm scripts

**One thing to decide, not just apply:** `lib/schemas.ts` currently
*duplicates* the seven Zod schemas that already live inline in
`app/actions.ts` (a `"use server"` file can only export async functions, so
the schemas can't be tested by importing them directly from `actions.ts`).
Right now they're identical, so nothing's broken — but they can drift if one
gets edited and not the other. If you want, tell me and I'll give you the
patch to make `actions.ts` import from `lib/schemas.ts` instead of
redefining them, which removes the duplication entirely. I didn't do that
here to keep this batch additive-only.

## 4. Add the new environment variables

Add to `.env.local` (get the Resend key at https://resend.com — free tier,
3k emails/month):

```
RESEND_API_KEY=re_xxx
NOTIFICATIONS_FROM_EMAIL=notifications@yourdomain.com
```

Optional (Slack alert on Critical/High vulnerability reports, in addition to
email):
```
SLACK_WEBHOOK_URL=https://hooks.slack.com/services/...
```

Until `RESEND_API_KEY` is set, every notification call just logs a warning
and skips sending — nothing breaks, applications/contact messages/reports
still save normally.

Also add these to `.env.example` (they were missing even though the Stripe
code already needs them):
```
STRIPE_SECRET_KEY=
STRIPE_WEBHOOK_SECRET=
```

## 5. Verify

```cmd
npx tsc --noEmit
npm run test
```

`tsc` should report 0 errors. `npm run test` runs the new Vitest suite
(`lib/departments.test.ts`, `lib/schemas.test.ts`) — should be all green,
no network/database needed for these.

To actually exercise the new audit log viewer:
```cmd
npm run dev
```
Sign in as a `founder`, go to `/admin`, click **Audit Log** in the sidebar,
then create/edit/delete a blog post and confirm it shows up.

E2E and accessibility tests need a full build first (Playwright's config
does this automatically):
```cmd
npm run test:e2e
```
This needs `NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_ANON_KEY`,
`NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY`, and `CLERK_SECRET_KEY` set in your
local `.env.local` (same ones `npm run dev` already needs) since it boots a
real production build of the app.

## 6. Push CI live

`.github/workflows/ci.yml` and `.github/dependabot.yml` do nothing until
pushed to GitHub and the required secrets are set:

**Settings → Secrets and variables → Actions**, add:
- `NEXT_PUBLIC_SUPABASE_URL`
- `NEXT_PUBLIC_SUPABASE_ANON_KEY`
- `SUPABASE_SERVICE_ROLE_KEY`
- `NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY`
- `CLERK_SECRET_KEY`

Once set, every PR runs lint → typecheck → unit tests → `npm audit` → build
→ E2E (including the axe-core accessibility pass), with the Playwright HTML
report attached as a downloadable artifact on failure.

---

## What's still genuinely open after this batch

Nothing left that's just "write more code" — what remains needs either your
business decisions or actual design/manual work, same as before:

| Item | Why it's not in this delivery |
|---|---|
| Real Spline scene with `scrollProgress` wired | Needs your actual Spline editor account — `components/SplineBackground.tsx` still points at a placeholder `.splinecode` URL, I can wire the `scrollProgress` variable through GSAP's `ScrollTrigger` once you have a real exported scene, but I can't design the scene itself |
| Manual accessibility pass (keyboard nav, alt-text quality) | `e2e/accessibility.spec.ts` covers the automatable subset (contrast, ARIA, labels) — a human still needs to tab through the site once |
| Penetration test | Needs your Red Team department, not code |
| Blog `published`/draft toggle | Not in your current schema at all — every blog post goes live immediately on create. Not on your priority list, flagging again since it's a real gap vs. the original Phase 10 spec, not a false alarm |
| Clerk JWT template `org_id` claim | `docs/clerk-supabase-jwt-template.md` already documents this — it's a Clerk Dashboard config step, not code |
| Staging Supabase/Clerk project | Infra setup, not code |
