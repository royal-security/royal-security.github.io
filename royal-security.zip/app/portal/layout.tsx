import { auth } from '@clerk/nextjs/server';
import { redirect } from 'next/navigation';

// Force dynamic rendering for all portal routes
export const dynamic = 'force-dynamic';
// Force no-store fetch cache for this entire segment
export const fetchCache = 'force-no-store';

export default async function PortalLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const { userId } = await auth();
  if (!userId) redirect('/sign-in');

  return (
    <div className="min-h-screen bg-navy">
      <header className="border-b border-gray-800 p-4 flex items-center justify-between">
        <span className="font-bold text-white">Royal Security Portal</span>
      </header>
      <main className="p-6">{children}</main>
    </div>
  );
}