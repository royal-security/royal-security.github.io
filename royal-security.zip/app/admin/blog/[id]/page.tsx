import { notFound } from "next/navigation";
import { createAdminClient } from "@/utils/supabase/admin";
import { BlogForm } from "@/components/admin/BlogForm";
import { requirePermissionPage } from "@/lib/roles-page";
import { PERMISSIONS } from "@/lib/roles";

export default async function EditBlogPostPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  await requirePermissionPage(PERMISSIONS.BLOG_WRITE);
  const { id } = await params;
  const supabase = createAdminClient();
  if (!supabase) return [];
  const { data: post } = await supabase
    .from("blog_posts")
    .select("id, title, slug, category, content")
    .eq("id", id)
    .single();

  if (!post) notFound();

  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">Edit Blog Post</h1>
      <BlogForm post={post} />
    </div>
  );
}
