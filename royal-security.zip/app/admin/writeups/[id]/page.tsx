import { notFound } from "next/navigation";
import { createAdminClient } from "@/utils/supabase/admin";
import { WriteupForm } from "@/components/admin/WriteupForm";
import { requirePermissionPage } from "@/lib/roles-page";
import { PERMISSIONS } from "@/lib/roles";

export default async function EditWriteupPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const claims = await requirePermissionPage(PERMISSIONS.WRITEUPS_WRITE);
  const { id } = await params;
  const supabase = createAdminClient();
  if (!supabase) return [];
  const { data: writeup } = await supabase
    .from("writeups")
    .select("id, title, slug, challenge_name, difficulty, category, content, is_gated, department")
    .eq("id", id)
    .single();

  if (!writeup) notFound();
  if (claims.role === "dept_lead" && writeup.department !== claims.department) notFound();

  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">Edit Writeup</h1>
      <WriteupForm writeup={writeup} lockedDepartment={claims.role === "dept_lead" ? claims.department : null} />
    </div>
  );
}
