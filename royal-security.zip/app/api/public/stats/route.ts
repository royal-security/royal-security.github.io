import { NextResponse } from "next/server";
import { createClient } from "@/utils/supabase/server";

export const dynamic = "force-static";
export const revalidate = 3600;

export async function GET() {
  const supabase = await createClient();
  const { data, error } = await supabase
    .from("site_config")
    .select("members_count, ctfs_participated, writeups_published")
    .single();

  if (error || !data) {
    // Fail soft: homepage still renders even if the config row hasn't been seeded yet.
    return NextResponse.json({ members_count: 0, ctfs_participated: 0, writeups_published: 0 });
  }

  return NextResponse.json(data);
}
