import type { Metadata } from "next";
import { ContactForm } from "./ContactForm";

export const metadata: Metadata = {
  title: "Contact",
  description: "Get in touch with Royal Security.",
};

// NOTE: placeholder links are prohibited per Section 7.2 of the blueprint.
// Replace every value below with your organization's real, verified accounts
// before deploying — this is the one section that cannot be auto-generated.
const links = [
  { label: "Email", href: "mailto:contact@royalsecurity.example" },
  { label: "Discord", href: "https://discord.gg/REPLACE_ME" },
  { label: "LinkedIn", href: "https://linkedin.com/company/REPLACE_ME" },
  { label: "Twitter / X", href: "https://x.com/REPLACE_ME" },
  { label: "GitHub", href: "https://github.com/REPLACE_ME" },
  { label: "YouTube", href: "https://youtube.com/@REPLACE_ME" },
];

export default function ContactPage() {
  return (
    <main className="container mx-auto px-4 py-24">
      <h1 className="text-4xl font-extrabold tracking-tight text-white sm:text-6xl">Contact</h1>

      <div className="mt-12 grid gap-12 lg:grid-cols-2">
        <ContactForm />

        <div>
          <h2 className="text-xl font-bold text-white">Direct Channels</h2>
          <ul className="mt-4 space-y-2">
            {links.map((l) => (
              <li key={l.label}>
                <a
                  href={l.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-muted-foreground hover:text-white"
                >
                  {l.label}
                </a>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </main>
  );
}
