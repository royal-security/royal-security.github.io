"use client";

import { useRef, useState, useTransition } from "react";
import { submitApplication } from "@/app/actions";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

export function JoinForm() {
  const formRef = useRef<HTMLFormElement>(null);
  const [status, setStatus] = useState<"idle" | "success" | "error">("idle");
  const [errorMessage, setErrorMessage] = useState("");
  const [isPending, startTransition] = useTransition();

  function handleSubmit(formData: FormData) {
    startTransition(async () => {
      try {
        await submitApplication(formData);
        setStatus("success");
        formRef.current?.reset();
      } catch (err) {
        setStatus("error");
        setErrorMessage(err instanceof Error ? err.message : "Submission failed");
      }
    });
  }

  return (
    <form ref={formRef} action={handleSubmit} className="mt-4 space-y-4">
      {/* Honeypot field — hidden from real users, catches bots that fill every field */}
      <div className="absolute left-[-9999px]" aria-hidden="true">
        <label htmlFor="website">Website</label>
        <input id="website" name="website" type="text" tabIndex={-1} autoComplete="off" />
      </div>

      <div>
        <label htmlFor="full_name" className="text-sm text-muted-foreground">
          Full Name
        </label>
        <Input id="full_name" name="full_name" required minLength={2} />
      </div>

      <div>
        <label htmlFor="email" className="text-sm text-muted-foreground">
          Email
        </label>
        <Input id="email" name="email" type="email" required />
      </div>

      <div>
        <label htmlFor="department_interest" className="text-sm text-muted-foreground">
          Department of Interest
        </label>
        <Input id="department_interest" name="department_interest" required minLength={2} />
      </div>

      <div>
        <label htmlFor="experience" className="text-sm text-muted-foreground">
          Relevant Experience
        </label>
        <textarea
          id="experience"
          name="experience"
          required
          minLength={10}
          rows={4}
          className="mt-1 w-full rounded-md border border-gray-800 bg-background p-2 text-sm text-white"
        />
      </div>

      <Button type="submit" disabled={isPending}>
        {isPending ? "Submitting…" : "Submit Application"}
      </Button>

      {status === "success" && (
        <p className="text-sm text-emerald-400">Application received — we&apos;ll be in touch.</p>
      )}
      {status === "error" && <p className="text-sm text-red-400">{errorMessage}</p>}
    </form>
  );
}
