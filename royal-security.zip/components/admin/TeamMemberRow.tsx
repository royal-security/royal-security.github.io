"use client";

import { useState } from "react";
import { upsertTeamMember, deleteTeamMember } from "@/app/actions";

const inputClass = "p-1.5 rounded bg-gray-800 border border-gray-700 text-white w-full text-sm";

type TeamMember = {
  id: string;
  name: string;
  role: string;
  department: string | null;
  sort_order: number;
};

export function TeamMemberRow({ member }: { member: TeamMember }) {
  const [editing, setEditing] = useState(false);

  if (editing) {
    return (
      <tr className="border-t border-gray-800 bg-gray-900/50">
        <td colSpan={5} className="p-3">
          <form
            action={async (formData) => {
              await upsertTeamMember(formData);
              setEditing(false);
            }}
            className="grid grid-cols-5 gap-2 items-end"
          >
            <input type="hidden" name="id" value={member.id} />
            <input name="name" defaultValue={member.name} required className={inputClass} placeholder="Name" />
            <input name="role" defaultValue={member.role} required className={inputClass} placeholder="Role" />
            <input
              name="department"
              defaultValue={member.department ?? ""}
              className={inputClass}
              placeholder="Department"
            />
            <input
              name="sort_order"
              type="number"
              defaultValue={member.sort_order}
              className={inputClass}
              placeholder="Sort order"
            />
            <div className="flex gap-2">
              <button type="submit" className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 rounded text-sm">
                Save
              </button>
              <button
                type="button"
                onClick={() => setEditing(false)}
                className="px-3 py-1.5 bg-gray-700 hover:bg-gray-600 rounded text-sm"
              >
                Cancel
              </button>
            </div>
          </form>
        </td>
      </tr>
    );
  }

  return (
    <tr className="border-t border-gray-800">
      <td className="p-3">{member.name}</td>
      <td className="p-3 text-gray-400">{member.role}</td>
      <td className="p-3 text-gray-400">{member.department ?? "—"}</td>
      <td className="p-3 text-gray-400">{member.sort_order}</td>
      <td className="p-3 text-right space-x-3">
        <button onClick={() => setEditing(true)} className="text-blue-400 hover:underline">
          Edit
        </button>
        <form action={deleteTeamMember} className="inline">
          <input type="hidden" name="id" value={member.id} />
          <button type="submit" className="text-red-400 hover:underline">
            Delete
          </button>
        </form>
      </td>
    </tr>
  );
}
