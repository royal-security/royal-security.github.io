import { clerkMiddleware, createRouteMatcher } from '@clerk/nextjs/server';
import { NextResponse } from 'next/server';

// Public routes that do not require authentication
const isPublicRoute = createRouteMatcher([
  '/',
  '/about(.*)',
  '/contact(.*)',
  '/join(.*)',
  '/departments(.*)',
  '/blog(.*)',
  '/writeups(.*)',
  '/code-of-conduct(.*)',
  '/privacy(.*)',
  '/api/public(.*)',
  '/sign-in(.*)',
  '/sign-up(.*)',
]);

// Secure routes that must never be cached by CDN
const isSecureRoute = createRouteMatcher([
  '/portal(.*)',
  '/api/secure(.*)',
  '/admin(.*)',
]);

export default clerkMiddleware(async (auth, req) => {
  if (isSecureRoute(req)) {
    await auth.protect();
  }

  const response = NextResponse.next();

  if (isSecureRoute(req)) {
    response.headers.set('Cache-Control', 'no-store, max-age=0');
    response.headers.set('Pragma', 'no-cache');
    response.headers.set('Expires', '0');
  }

  return response;
});

export const config = {
  matcher: [
    '/((?!_next|[^?]*\\.(?:html?|css|js(?!on)|jpe?g|webp|png|gif|svg|ttf|woff2?|ico|csv|docx?|xlsx?|zip|webmanifest)).*)',
    '/(api|trpc)(.*)',
  ],
};