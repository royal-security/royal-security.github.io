import { clerkClient } from "@clerk/nextjs/server";
import { createAdminClient } from "@/utils/supabase/admin";
import { requirePermissionPage } from "@/lib/roles-page";
import { PERMISSIONS } from "@/lib/roles";
import { linkOrgStripeCustomer } from "@/app/actions";

export const dynamic = "force-dynamic";

const inputClass = "p-2 rounded bg-gray-800 border border-gray-700 text-white text-sm";

async function getOrgsWithBilling() {
  const client = await clerkClient();
  const { data: orgs } = await client.organizations.getOrganizationList({ limit: 100 });

  const supabase = createAdminClient();
  if (!supabase) return [];
  const { data: billingRows } = await supabase
    .from("org_billing")
    .select("org_id, stripe_customer_id, subscription_status");

  const billingByOrg = new Map((billingRows ?? []).map((b) => [b.org_id, b]));

  return orgs.map((org) => ({
    id: org.id,
    name: org.name,
    billing: billingByOrg.get(org.id) ?? null,
  }));
}

export default async function AdminBillingPage() {
  await requirePermissionPage(PERMISSIONS.ROLE_MANAGE);
  const orgs = await getOrgsWithBilling();

  return (
    <div>
      <h1 className="text-2xl font-bold mb-2">Billing</h1>
      <p className="text-sm text-gray-400 mb-6">
        Link each client organization to its Stripe customer. There's no automated customer-creation
        flow yet — create the customer in Stripe first, then paste its ID here. See{" "}
        <code className="text-gray-300">docs/billing-stripe-scope.md</code> for the full setup.
      </p>

      <div className="rounded-lg border border-gray-800 overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-gray-900 text-gray-400">
            <tr>
              <th className="text-left p-3">Organization</th>
              <th className="text-left p-3">Stripe Customer</th>
              <th className="text-left p-3">Subscription</th>
              <th className="text-left p-3">Link / Update</th>
            </tr>
          </thead>
          <tbody>
            {orgs.map((org) => (
              <tr key={org.id} className="border-t border-gray-800">
                <td className="p-3">{org.name}</td>
                <td className="p-3 text-gray-400 font-mono text-xs">
                  {org.billing?.stripe_customer_id ?? "Not linked"}
                </td>
                <td className="p-3 text-gray-400">{org.billing?.subscription_status ?? "—"}</td>
                <td className="p-3">
                  <form action={linkOrgStripeCustomer} className="flex gap-2">
                    <input type="hidden" name="org_id" value={org.id} />
                    <input
                      name="stripe_customer_id"
                      placeholder="cus_..."
                      defaultValue={org.billing?.stripe_customer_id ?? ""}
                      required
                      className={inputClass}
                    />
                    <button type="submit" className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 rounded text-sm">
                      Save
                    </button>
                  </form>
                </td>
              </tr>
            ))}
            {orgs.length === 0 && (
              <tr>
                <td colSpan={4} className="p-6 text-center text-gray-500">
                  No Clerk organizations found.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
