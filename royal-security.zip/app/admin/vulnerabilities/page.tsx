import { createAdminClient } from "@/utils/supabase/admin";
import { submitVulnerabilityReport } from "@/app/actions";
import { requirePermissionPage } from "@/lib/roles-page";
import { PERMISSIONS } from "@/lib/roles";
import { VulnerabilityReportRow } from "@/components/admin/VulnerabilityReportRow";

export const dynamic = "force-dynamic";

const inputClass = "p-2 rounded bg-gray-800 border border-gray-700 text-white";

const SEVERITY_COLORS: Record<string, string> = {
  Critical: "text-red-400",
  High: "text-orange-400",
  Medium: "text-amber-400",
  Low: "text-gray-400",
};

async function getReports() {
  const supabase = createAdminClient();
  if (!supabase) return [];
  const { data } = await supabase
    .from("vulnerability_reports")
    .select("id, title, severity, status, affected_asset, org_id, report_path, created_at")
    .order("created_at", { ascending: false });
  return data ?? [];
}

export default async function AdminVulnerabilitiesPage() {
  await requirePermissionPage(PERMISSIONS.REPORTS_READ);
  const reports = await getReports();

  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">Vulnerability Reports</h1>

      <div className="mb-8 p-6 rounded-lg border border-gray-800 bg-gray-900/50">
        <h2 className="text-lg font-semibold mb-4 text-emerald-400">Submit Report</h2>
        <p className="text-xs text-gray-500 mb-4">
          Note: this form requires the submitting user to be signed in and a member of a Clerk
          organization — it inserts against that org, not as an admin action.
        </p>
        <form action={submitVulnerabilityReport} className="grid gap-4">
          <input name="title" placeholder="Title" required className={inputClass} />
          <select name="severity" required className={inputClass}>
            <option value="Critical">Critical</option>
            <option value="High">High</option>
            <option value="Medium">Medium</option>
            <option value="Low">Low</option>
          </select>
          <textarea
            name="description"
            placeholder="Description (at least 20 chars)"
            required
            className={`${inputClass} h-24`}
          />
          <input name="affected_asset" placeholder="Affected Asset" required className={inputClass} />
          <button
            type="submit"
            className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 rounded font-semibold transition w-fit"
          >
            Submit Report
          </button>
        </form>
      </div>

      <div className="rounded-lg border border-gray-800 overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-gray-900 text-gray-400">
            <tr>
              <th className="text-left p-3">Title</th>
              <th className="text-left p-3">Severity</th>
              <th className="text-left p-3">Asset</th>
              <th className="text-left p-3">Org</th>
              <th className="text-left p-3">Status</th>
              <th className="text-left p-3">Report</th>
            </tr>
          </thead>
          <tbody>
            {reports.map((r) => (
              <tr key={r.id} className="border-t border-gray-800 align-top">
                <td className="p-3">{r.title}</td>
                <td className={`p-3 font-medium ${SEVERITY_COLORS[r.severity] ?? ""}`}>{r.severity}</td>
                <td className="p-3 text-gray-400">{r.affected_asset}</td>
                <td className="p-3 text-gray-400 font-mono text-xs">{r.org_id}</td>
                <td className="p-3">
                  <div className="flex flex-col gap-2">
                    <VulnerabilityReportRow report={{ id: r.id, status: r.status, report_path: r.report_path }} />
                  </div>
                </td>
                <td className="p-3 text-gray-500 text-xs">
                  {r.report_path ? "PDF on file" : "None uploaded"}
                </td>
              </tr>
            ))}
            {reports.length === 0 && (
              <tr>
                <td colSpan={6} className="p-6 text-center text-gray-500">
                  No reports yet.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
