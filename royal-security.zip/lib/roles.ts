import { auth } from '@clerk/nextjs/server';
import { redirect } from 'next/navigation';

export type Role = 'founder' | 'dept_lead' | 'content_editor' | 'client_success' | 'member';

export const ROLE_LABELS: Record<Role, string> = {
  founder: 'Founder',
  dept_lead: 'Department Lead',
  content_editor: 'Content Editor',
  client_success: 'Client Success',
  member: 'Member',
};

export const PERMISSIONS = {
  BLOG_WRITE: 'blog_write',
  WRITEUPS_WRITE: 'writeups_write',
  CTF_WRITE: 'ctf_write',
  TEAM_WRITE: 'team_write',
  APPLICATIONS_MANAGE: 'applications_manage',
  MESSAGES_READ: 'messages_read',
  REPORTS_READ: 'reports_read',
  REPORTS_UPLOAD: 'reports_upload',
  SITE_CONFIG_WRITE: 'site_config_write',
  ROLE_MANAGE: 'role_manage',
  AUDIT_READ: 'audit_read',
} as const;

export type Permission = (typeof PERMISSIONS)[keyof typeof PERMISSIONS];

const ROLE_PERMISSIONS: Record<Role, Permission[]> = {
  founder: Object.values(PERMISSIONS),
  dept_lead: [PERMISSIONS.WRITEUPS_WRITE, PERMISSIONS.CTF_WRITE],
  content_editor: [PERMISSIONS.BLOG_WRITE],
  client_success: [PERMISSIONS.APPLICATIONS_MANAGE, PERMISSIONS.MESSAGES_READ],
  member: [],
};

export const normalizeRole = (role: unknown): Role => {
  const validRoles: Role[] = ['founder', 'dept_lead', 'content_editor', 'client_success', 'member'];
  return validRoles.includes(role as Role) ? (role as Role) : 'member';
};

export const can = (role: Role, permission: Permission): boolean => {
  return ROLE_PERMISSIONS[role]?.includes(permission) ?? false;
};

export const getRoleClaims = (sessionClaims: unknown): { role: Role } => {
  const metadata = (sessionClaims as { metadata?: { role?: unknown } } | null)?.metadata;
  return { role: normalizeRole(metadata?.role) };
};

export const requireRolePage = async (allowedRoles: Role[]): Promise<Role> => {
  const { sessionClaims } = await auth();
  const { role } = getRoleClaims(sessionClaims);
  if (!allowedRoles.includes(role)) {
    redirect('/portal/learner');
  }
  return role;
};