import { createAdminClient } from "@/utils/supabase/admin";
import { requirePermissionPage } from "@/lib/roles-page";
import { PERMISSIONS } from "@/lib/roles";

export const dynamic = "force-dynamic";

async function getMessages() {
  const supabase = createAdminClient();
  if (!supabase) return [];
  const { data } = await supabase
    .from("contact_messages")
    .select("id, name, email, message, created_at")
    .order("created_at", { ascending: false });
  return data ?? [];
}

export default async function AdminContactPage() {
  await requirePermissionPage(PERMISSIONS.MESSAGES_READ);
  const messages = await getMessages();

  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">Contact Messages ({messages.length})</h1>

      <div className="flex flex-col gap-3">
        {messages.map((m) => (
          <div key={m.id} className="p-4 rounded-lg border border-gray-800 bg-gray-900/50">
            <div className="flex items-start justify-between gap-4">
              <div>
                <div className="font-semibold">{m.name}</div>
                <div className="text-sm text-gray-400">{m.email}</div>
              </div>
              <span className="text-xs text-gray-500 shrink-0">
                {new Date(m.created_at).toLocaleDateString()}
              </span>
            </div>
            <p className="text-sm text-gray-300 mt-3 whitespace-pre-wrap">{m.message}</p>
          </div>
        ))}
        {messages.length === 0 && (
          <p className="text-center text-gray-500 py-10">No messages yet.</p>
        )}
      </div>
    </div>
  );
}
