import { CTFForm } from "@/components/admin/CTFForm";
import { requirePermissionPage } from "@/lib/roles-page";
import { PERMISSIONS } from "@/lib/roles";

export default async function NewCTFModulePage() {
  const claims = await requirePermissionPage(PERMISSIONS.CTF_WRITE);
  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">New CTF Module</h1>
      <CTFForm lockedDepartment={claims.role === "dept_lead" ? claims.department : null} />
    </div>
  );
}
