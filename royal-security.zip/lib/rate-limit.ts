import { Ratelimit } from '@upstash/ratelimit';
import { Redis } from '@upstash/redis';

const redis = Redis.fromEnv();

const instances = new Map<string, Ratelimit>();

function getLimiter(limit: number, windowSeconds: number): Ratelimit {
  const key = `${limit}:${windowSeconds}`;
  let instance = instances.get(key);
  if (!instance) {
    instance = new Ratelimit({
      redis,
      limiter: Ratelimit.slidingWindow(limit, `${windowSeconds} s`),
      analytics: true,
    });
    instances.set(key, instance);
  }
  return instance;
}

export async function rateLimit({
  route,
  limit = 5,
  windowSeconds = 10,
}: {
  route: string;
  limit?: number;
  windowSeconds?: number;
}): Promise<{ ok: boolean; retryAfterSeconds: number }> {
  const limiter = getLimiter(limit, windowSeconds);
  const result = await limiter.limit(route);
  const retryAfterSeconds = Math.max(0, Math.ceil((result.reset - Date.now()) / 1000));
  return { ok: result.success, retryAfterSeconds };
}

export const ratelimit = getLimiter(5, 10);