"use client";

import { createContext, useContext, useEffect, useState } from "react";
import { usePathname } from "next/navigation";
import { departments, DEFAULT_ACCENT_HSL, type Department } from "@/lib/departments";

type ThemeContextType = {
  department: Department | null;
};

const ThemeContext = createContext<ThemeContextType>({ department: null });

export function ThemeProvider({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const [department, setDepartment] = useState<Department | null>(null);

  useEffect(() => {
    const root = document.documentElement;

    // Match against all 8 departments defined in lib/departments.ts instead of
    // a hardcoded 3-department list, so every /departments/[slug] route themes correctly.
    const match = departments.find((d) => pathname?.startsWith(`/departments/${d.slug}`));

    root.style.setProperty("--department-accent", match ? match.hsl : DEFAULT_ACCENT_HSL);
    setDepartment(match ?? null);
  }, [pathname]);

  return (
    <ThemeContext.Provider value={{ department }}>
      {children}
    </ThemeContext.Provider>
  );
}

export const useTheme = () => useContext(ThemeContext);
