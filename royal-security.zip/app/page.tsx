import SplineBackground from "@/components/SplineBackground";
import { Card, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

export default function Home() {
  return (
    <main className="relative min-h-screen">
      {/* Phase 5: Anti-Gravity 3D WebGL Canvas */}
      <SplineBackground />

      {/* Global Navigation is now mounted once in app/layout.tsx — don't render it here too */}

      {/* Hero Section */}
      <div className="relative z-10 flex flex-col items-center justify-center min-h-[85vh] px-4 text-center">
        <Badge className="mb-6 bg-department text-white px-4 py-1 text-sm border-none transition-colors duration-500">
          Next-Gen Threat Modeling
        </Badge>

        <h1 className="max-w-4xl text-5xl font-extrabold tracking-tight text-white sm:text-7xl md:text-8xl">
          Secure the <span className="text-transparent bg-clip-text bg-gradient-to-r from-gray-400 to-white">Unknown.</span>
        </h1>

        <p className="mt-6 max-w-2xl text-lg text-muted-foreground md:text-xl">
          Advanced B2B vulnerability auditing, offensive security training, and real-time infrastructure defense mechanisms.
        </p>
      </div>

      {/* Feature Grid (Scroll Down to reveal) */}
      <div className="relative z-10 container mx-auto px-4 pb-24">
        <div className="grid gap-6 md:grid-cols-3">
          <Card className="bg-card/50 border-gray-800 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-white">Red Teaming</CardTitle>
              <CardDescription>Simulated adversarial attacks identifying critical infrastructure vulnerabilities before deployment.</CardDescription>
            </CardHeader>
          </Card>

          <Card className="bg-card/50 border-gray-800 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-white">Hardware Exploitation</CardTitle>
              <CardDescription>Advanced RF analysis and embedded system penetration testing for IoT devices.</CardDescription>
            </CardHeader>
          </Card>

          <Card className="bg-card/50 border-gray-800 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-white">Zero-Day Research</CardTitle>
              <CardDescription>Proprietary vulnerability discovery and custom exploit development methodologies.</CardDescription>
            </CardHeader>
          </Card>
        </div>
      </div>
    </main>
  );
}
