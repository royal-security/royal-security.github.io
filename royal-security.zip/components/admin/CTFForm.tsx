"use client";

import { useRouter } from "next/navigation";
import { createCTFModule, updateCTFModule } from "@/app/actions";

const DIFFICULTIES = ["Beginner", "Intermediate", "Advanced"];
const inputClass = "p-2 rounded bg-gray-800 border border-gray-700 text-white w-full";

type CTFModule = {
  id: string;
  title: string;
  category: string;
  difficulty: string;
  content: string;
  department?: string | null;
};

export function CTFForm({
  mod,
  lockedDepartment,
}: {
  mod?: CTFModule;
  /** Non-null when the signed-in user is a dept_lead: department is fixed to
   * their own and rendered read-only. Null for founder, who can set it freely. */
  lockedDepartment?: string | null;
}) {
  const router = useRouter();
  const action = mod ? updateCTFModule : createCTFModule;

  async function handleSubmit(formData: FormData) {
    if (mod) formData.set("module_id", mod.id);
    await action(formData);
    router.push("/admin/ctf");
  }

  return (
    <form action={handleSubmit} className="grid gap-4 max-w-2xl">
      <div>
        <label className="text-sm text-gray-400 mb-1 block">Title</label>
        <input name="title" defaultValue={mod?.title} required className={inputClass} />
      </div>
      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="text-sm text-gray-400 mb-1 block">Category</label>
          <input name="category" defaultValue={mod?.category} required className={inputClass} />
        </div>
        <div>
          <label className="text-sm text-gray-400 mb-1 block">Difficulty</label>
          <select
            name="difficulty"
            defaultValue={mod?.difficulty ?? DIFFICULTIES[0]}
            required
            className={inputClass}
          >
            {DIFFICULTIES.map((d) => (
              <option key={d} value={d}>
                {d}
              </option>
            ))}
          </select>
        </div>
      </div>
      <div>
        <label className="text-sm text-gray-400 mb-1 block">Department</label>
        {lockedDepartment !== undefined && lockedDepartment !== null ? (
          <>
            <input value={lockedDepartment} disabled className={`${inputClass} opacity-60`} />
            <p className="text-xs text-gray-500 mt-1">
              Locked to your department — dept_leads can only publish under their own.
            </p>
          </>
        ) : (
          <input
            name="department"
            defaultValue={mod?.department ?? ""}
            placeholder="e.g. red-team (optional)"
            className={inputClass}
          />
        )}
      </div>
      <div>
        <label className="text-sm text-gray-400 mb-1 block">Content</label>
        <textarea
          name="content"
          defaultValue={mod?.content}
          required
          className={`${inputClass} h-64 font-mono text-sm`}
        />
      </div>
      <button
        type="submit"
        className="px-4 py-2 bg-blue-600 hover:bg-blue-500 rounded font-semibold transition w-fit"
      >
        {mod ? "Save Changes" : "Create Module"}
      </button>
    </form>
  );
}
