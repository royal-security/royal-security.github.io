# Patch: components/Navbar.tsx (Phase 15 — Logo)

Find:
```tsx
          <Link href="/" className="flex items-center space-x-2">
            <span className="text-xl font-bold tracking-tighter text-white">
              ROYAL<span className="text-department transition-colors duration-500">SEC</span>
            </span>
          </Link>
```

Replace with:
```tsx
          <Link href="/" className="flex items-center gap-2">
            <img
              src="/logo.svg"
              alt=""
              width={28}
              height={28}
              className="text-department transition-colors duration-500"
            />
            <span className="text-xl font-bold tracking-tighter text-white">
              ROYAL<span className="text-department transition-colors duration-500">SEC</span>
            </span>
          </Link>
```

`public/logo.svg` uses `stroke="currentColor"` / `fill="currentColor"` on its
accent elements, so it inherits `text-department` the same way the wordmark
already does — the shield recolors with the active department, no extra
wiring needed. `alt=""` is intentional: the adjacent "ROYALSEC" text already
conveys the same information, so the icon is decorative to a screen reader
(this is also what the Phase 15 accessibility pass would otherwise flag).
