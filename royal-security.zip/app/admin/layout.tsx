import { auth } from "@clerk/nextjs/server";
import { redirect } from "next/navigation";
import Link from "next/link";
import { normalizeRole, type Role } from "@/lib/roles";

export const NAV: { href: string; label: string; roles: Role[] }[] = [
  { href: "/admin/blog", label: "Blog", roles: ["founder", "content_editor"] },
  { href: "/admin/writeups", label: "Writeups", roles: ["founder", "dept_lead"] },
  { href: "/admin/team", label: "Team", roles: ["founder"] },
  { href: "/admin/applications", label: "Applications", roles: ["founder", "client_success"] },
  { href: "/admin/contact", label: "Contact Messages", roles: ["founder", "client_success"] },
  { href: "/admin/vulnerabilities", label: "Vulnerability Reports", roles: ["founder"] },
  { href: "/admin/ctf", label: "CTF Modules", roles: ["founder", "dept_lead"] },
  { href: "/admin/stats", label: "Site Stats", roles: ["founder"] },
  { href: "/admin/billing", label: "Billing", roles: ["founder"] },
  { href: "/admin/audit-log", label: "Audit Log", roles: ["founder"] },
];

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  const { userId, sessionClaims } = await auth();
  const metadata = (sessionClaims?.metadata ?? {}) as { role?: string };
  const role = normalizeRole(metadata.role);

  if (!userId) redirect("/sign-in");
  if (role === "member") redirect("/portal/learner");

  const items = NAV.filter((item) => item.roles.includes(role));

  return (
    <div className="min-h-screen flex text-white">
      <aside className="w-56 shrink-0 border-r border-gray-800 bg-gray-950/50 p-4">
        <h1 className="text-lg font-bold mb-1 px-2">Admin</h1>
        <p className="text-xs text-gray-500 mb-6 px-2 capitalize">{role.replace("_", " ")}</p>
        <nav className="flex flex-col gap-1">
          {items.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className="px-2 py-2 rounded text-sm text-gray-300 hover:bg-gray-800 hover:text-white transition"
            >
              {item.label}
            </Link>
          ))}
        </nav>
      </aside>
      <main className="flex-1 p-8 max-w-5xl">{children}</main>
    </div>
  );
}
