"use client";

import { useRef, useState, useTransition } from "react";
import { submitContactMessage } from "@/app/actions";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

export function ContactForm() {
  const formRef = useRef<HTMLFormElement>(null);
  const [status, setStatus] = useState<"idle" | "success" | "error">("idle");
  const [errorMessage, setErrorMessage] = useState("");
  const [isPending, startTransition] = useTransition();

  function handleSubmit(formData: FormData) {
    startTransition(async () => {
      try {
        await submitContactMessage(formData);
        setStatus("success");
        formRef.current?.reset();
      } catch (err) {
        setStatus("error");
        setErrorMessage(err instanceof Error ? err.message : "Submission failed");
      }
    });
  }

  return (
    <form ref={formRef} action={handleSubmit} className="space-y-4">
      <div className="absolute left-[-9999px]" aria-hidden="true">
        <label htmlFor="website">Website</label>
        <input id="website" name="website" type="text" tabIndex={-1} autoComplete="off" />
      </div>

      <div>
        <label htmlFor="name" className="text-sm text-muted-foreground">
          Name
        </label>
        <Input id="name" name="name" required minLength={2} />
      </div>

      <div>
        <label htmlFor="email" className="text-sm text-muted-foreground">
          Email
        </label>
        <Input id="email" name="email" type="email" required />
      </div>

      <div>
        <label htmlFor="message" className="text-sm text-muted-foreground">
          Message
        </label>
        <textarea
          id="message"
          name="message"
          required
          minLength={10}
          rows={5}
          className="mt-1 w-full rounded-md border border-gray-800 bg-background p-2 text-sm text-white"
        />
      </div>

      <Button type="submit" disabled={isPending}>
        {isPending ? "Sending…" : "Send Message"}
      </Button>

      {status === "success" && (
        <p className="text-sm text-emerald-400">Message sent — thanks for reaching out.</p>
      )}
      {status === "error" && <p className="text-sm text-red-400">{errorMessage}</p>}
    </form>
  );
}
