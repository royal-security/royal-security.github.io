# Headache Fix — Full Diagnosis & Installation Guide

Verified against your actual `package.json` — 0 TypeScript errors after every fix below.

## What Was Actually Wrong (5 Root Causes)

### 1. Your "current" export was missing 15 admin pages + 6 form components
Your `royal-security-current.zip` was taken from an older/different working copy than
`royal-security-phase10-11-13-16.zip`. The nav in `app/admin/layout.tsx` still linked to
`/admin/blog`, `/admin/writeups`, `/admin/ctf`, `/admin/team`, `/admin/applications`,
`/admin/contact`, `/admin/vulnerabilities`, `/admin/stats`, `/admin/billing` — but those page
files didn't exist. Clicking them 404'd.

**Fixed:** restored all 15 pages + 6 components from your earlier upload.

### 2. Your role system was upgraded, but 3 files never caught up
At some point `lib/roles.ts` was rebuilt from a simple role-list check into a proper permission
system (`can(role, PERMISSIONS.X)`) — a real improvement. But `app/admin/audit-log/page.tsx` and
`app/admin/layout.tsx` (from my earlier Phase 13.1 delivery) still called `requireRolePage()` and
`getRoleClaims()` — functions that no longer exist in your rebuilt `roles.ts`. That's a hard
compile error, not a runtime bug — TypeScript should have caught this immediately if you'd run
`npx tsc --noEmit` before copying files in.

**Fixed:** created one shared helper, `lib/roles-page.ts::requirePermissionPage()`, and every
admin page now uses it consistently. This can't drift the same way again because there's only one
place to update.

### 3. A live, silent bug: founders were locked out of their own dashboard
`app/admin/page.tsx` still checked `role !== "admin"` — the old pre-permission-system flag. Your
real roles are `founder`, `dept_lead`, `content_editor`, `client_success`, `member`. A founder
visiting `/admin` directly would fail that check and get redirected to `/sign-in` — even though
the layout around it already correctly let them in. This wasn't a build error, so it would have
kept silently locking you out until someone happened to debug it.

**Fixed:** rewrote `app/admin/page.tsx` as a role-aware dashboard that links only to sections the
signed-in user actually has permission for.

### 4. The `audit_log` table's real column names didn't match my original code
Your actual `audit_log` table (in `supabase/schema.sql`) uses `entity` / `entity_id` columns.
My original Phase 13.1 delivery queried `target_table` / `target_id` — columns that don't exist in
your schema. It would have compiled fine in isolation but silently returned wrong/empty results
against your real database.

**Fixed:** `lib/audit-read.ts` and the audit log page now query `entity` / `entity_id`, and
`humanizeAction()` now matches your actual action-naming convention (`create_blog_post`, not
`blog_posts.create`).

### 5. Two entire Phase 16 subsystems were missing from `app/actions.ts`
`updateVulnerabilityReportStatus`, `uploadVulnerabilityReportPdf`, and the whole Stripe billing
scaffold (`linkOrgStripeCustomer`, `createBillingPortalSession`, `utils/stripe.ts`) existed in
your older upload but were absent from "current" — same root cause as #1.

**Fixed:** restored all three functions, adapted to call `requirePermission(PERMISSIONS.X)`
(your current pattern) instead of the old `requireRole([...])`, and fixed their audit log calls to
use `entity`/`entityId` instead of the old `targetTable`/`targetId`.

### Bonus: a duplicate `phase2-delivery/` folder
A full copy of an earlier patch zip was sitting *inside* your live project instead of being merged
and deleted. Not routed by Next.js, but your `tsconfig.json` type-checks everything except
`node_modules`, so it doubled every error message and added noise. **Deleted** — not included in
this delivery, so it simply won't come back if you copy these files in cleanly.

---

## Installation (Windows cmd, from `F:\Royal-enterprise\royal-security>`)

### 1. Back up first
```cmd
xcopy /E /I . ..\royal-security-backup-before-fix
```

### 2. Delete the duplicate folder if it's still there
```cmd
rmdir /S /Q phase2-delivery
```
(If it doesn't exist, this will just say "The system cannot find the file specified" — that's fine.)

### 3. Extract this delivery zip
```cmd
tar -xf headache-fix.zip
```
This will overwrite `app/actions.ts`, `app/admin/layout.tsx`, and `app/admin/page.tsx`, and add
every restored file into place.

### 4. Install the one new dependency (Stripe SDK)
```cmd
npm install stripe
```

### 5. Type-check — should return nothing (0 errors)
```cmd
npx tsc --noEmit
```

### 6. Add billing env vars (optional — only if you want billing working)
```cmd
notepad .env.local
```
Add:
```
STRIPE_SECRET_KEY=sk_test_your_key_here
NEXT_PUBLIC_APP_URL=http://localhost:3000
```
Without these, every other part of the app works fine — `createBillingPortalSession()` will just
throw a clear "billing isn't configured" error if someone tries to use it, rather than crashing
anything else. Stripe is free until you actually process a real payment.

### 7. Run it
```cmd
npm run dev
```

### 8. Sanity-check the fixes
- Sign in as a **founder** → go to `/admin` directly → confirm you land on the dashboard, not
  redirected to sign-in (this was the live bug from #3)
- Click every sidebar link (Blog, Writeups, Team, Applications, Contact, Vulnerability Reports,
  CTF Modules, Site Stats, Billing, Audit Log) → confirm none 404
- Create a blog post → go to `/admin/audit-log` → confirm the entry appears with the correct
  entity name and a readable action label

---

## Commit This State So You Never Lose Track Again

```cmd
git add -A
git commit -m "Restore missing Phase 16 files, fix role-system drift, fix founder lockout bug, fix audit_log column mismatch"
```

From here forward: run `git status` and `git diff` before you ever wonder "what did I change" —
that question shouldn't require re-uploading zips and diffing them by hand again.

## What's Genuinely NOT Done Yet (Honest Status)

- Billing works end-to-end for linking a customer and opening the portal, but there's still no
  Stripe *webhook* handler to sync subscription status changes back — that's still open work,
  documented in `docs/billing-stripe-scope.md`
- No automated tests were added in this pass — this was a diagnose-and-repair pass, not new
  feature work
