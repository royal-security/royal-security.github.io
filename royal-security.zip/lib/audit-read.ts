import { createAdminClient } from "@/utils/supabase/admin";

export type AuditLogEntry = {
  id: string;
  actor_id: string;
  actor_role: string | null;
  action: string;
  entity: string;
  entity_id: string | null;
  before: unknown | null;
  after: unknown | null;
  ip: string | null;
  created_at: string;
};

export type AuditLogFilters = {
  action?: string;
  actor_id?: string;
  entity?: string;
  limit?: number;
  offset?: number;
};

/**
 * Fetch audit log entries with optional filtering.
 * Used only by permitted admin roles via /admin/audit-log — no client-side access.
 * Service-role client bypasses RLS by design (audit_log has no policies).
 * Returns an empty result set if the service role key isn't configured,
 * rather than throwing — the audit log page should degrade gracefully.
 */
export async function getAuditLogs(filters?: AuditLogFilters): Promise<{
  entries: AuditLogEntry[];
  total: number;
}> {
  const supabase = createAdminClient();
  if (!supabase) {
    console.warn("[audit-read] SUPABASE_SERVICE_ROLE_KEY not configured — returning empty log");
    return { entries: [], total: 0 };
  }

  const limit = filters?.limit ?? 20;
  const offset = filters?.offset ?? 0;

  let query = supabase
    .from("audit_log")
    .select("*", { count: "exact" })
    .order("created_at", { ascending: false });

  if (filters?.action) {
    query = query.ilike("action", `%${filters.action}%`);
  }
  if (filters?.actor_id) {
    query = query.eq("actor_id", filters.actor_id);
  }
  if (filters?.entity) {
    query = query.eq("entity", filters.entity);
  }

  const { data, count, error } = await query.range(offset, offset + limit - 1);

  if (error) {
    throw new Error(`Audit log query failed: ${error.message}`);
  }

  return {
    entries: (data ?? []) as AuditLogEntry[],
    total: count ?? 0,
  };
}

/**
 * Get distinct action names for the filter dropdown.
 */
export async function getDistinctActions(): Promise<string[]> {
  const supabase = createAdminClient();
  if (!supabase) return [];

  const { data, error } = await supabase.from("audit_log").select("action").order("action");

  if (error || !data) return [];
  const unique = Array.from(new Set(data.map((d) => (d as { action: string }).action)));
  return unique.sort();
}

/**
 * Format the before/after JSONB for display in the table.
 */
export function formatChange(before: unknown, after: unknown): string {
  if (!before && !after) return "—";
  if (!before) return `created: ${JSON.stringify(after).slice(0, 100)}...`;
  if (!after) return `deleted`;

  const beforeStr = typeof before === "string" ? before : JSON.stringify(before);
  const afterStr = typeof after === "string" ? after : JSON.stringify(after);
  if (beforeStr === afterStr) return "no change";
  return `${beforeStr.slice(0, 50)}... → ${afterStr.slice(0, 50)}...`;
}

/**
 * Map action names to human-readable labels for the table.
 */
export function humanizeAction(action: string): string {
  const map: Record<string, string> = {
    create_blog_post: "Created blog post",
    update_blog_post: "Updated blog post",
    delete_blog_post: "Deleted blog post",
    create_writeup: "Created writeup",
    update_writeup: "Updated writeup",
    delete_writeup: "Deleted writeup",
    create_team_member: "Added team member",
    update_team_member: "Updated team member",
    delete_team_member: "Removed team member",
    create_ctf_module: "Created CTF module",
    update_ctf_module: "Updated CTF module",
    delete_ctf_module: "Deleted CTF module",
    update_site_config: "Updated site stats",
    submit_vulnerability_report: "Submitted vulnerability report",
    update_application_status: "Updated application status",
    upload_audit_report: "Uploaded audit report",
    update_vulnerability_report_status: "Updated report status",
    upload_vulnerability_report_pdf: "Uploaded report PDF",
    link_org_billing_customer: "Linked Stripe customer",
  };
  return map[action] ?? action;
}
