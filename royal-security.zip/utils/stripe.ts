import Stripe from "stripe";

// Requires STRIPE_SECRET_KEY. If unset, every function here throws a clear
// error instead of crashing at import time — so the rest of the app keeps
// working even before billing is configured. See docs/billing-stripe-scope.md.
let _stripe: Stripe | null = null;

export function getStripe(): Stripe {
  if (_stripe) return _stripe;
  const key = process.env.STRIPE_SECRET_KEY;
  if (!key) {
    throw new Error(
      "STRIPE_SECRET_KEY is not set — billing isn't configured yet. See docs/billing-stripe-scope.md."
    );
  }
  _stripe = new Stripe(key);
  return _stripe;
}

export function isBillingConfigured() {
  return Boolean(process.env.STRIPE_SECRET_KEY);
}
