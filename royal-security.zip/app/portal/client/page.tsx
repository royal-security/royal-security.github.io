'use client';
import { OrganizationSwitcher, useOrganization } from '@clerk/nextjs';
import { useEffect, useState } from 'react';
import { ReportsTable } from '@/components/portal/ReportsTable';

type Report = {
  id: string;
  title: string;
  severity: 'Critical' | 'High' | 'Medium' | 'Low';
  status: 'Open' | 'In Remediation' | 'Resolved';
  affected_asset: string;
  report_path: string | null;
  created_at: string;
};

export default function ClientPortal() {
  const { organization } = useOrganization();
  const [vulns, setVulns] = useState<Report[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (organization) {
      setLoading(true);
      fetch('/api/secure/vulnerabilities')
        .then((res) => res.json())
        .then((data) => setVulns(data.data || []))
        .finally(() => setLoading(false));
    }
  }, [organization]);

  return (
    <div className="p-8 text-white min-h-screen bg-[#0B1120]">
      <header className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold">Client Security Portal</h1>
        <OrganizationSwitcher appearance={{ elements: { organizationSwitcherTrigger: 'text-white' } }} />
      </header>

      <section className="mb-8">
        <h2 className="text-xl mb-4 text-[#00A8FF]">Severity Matrix</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {['Critical', 'High', 'Medium', 'Low'].map((sev) => (
            <div key={sev} className="p-6 bg-slate-900 border border-slate-800 rounded-lg text-center">
              <h3 className="text-gray-400 uppercase tracking-widest text-xs mb-2">{sev}</h3>
              <p className="text-4xl font-bold">{vulns.filter((v) => v.severity === sev).length}</p>
            </div>
          ))}
        </div>
      </section>

      <section>
        <h2 className="text-xl mb-4 text-[#00A8FF]">Vulnerability Reports</h2>
        {loading ? (
          <div className="p-6 bg-slate-900 border border-slate-800 rounded-lg">
            <p className="text-gray-400">Loading reports…</p>
          </div>
        ) : (
          <ReportsTable reports={vulns} />
        )}
      </section>
    </div>
  );
}
