import Link from "next/link";

export default function NotFound() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-center bg-background px-4 text-center">
      <span className="text-sm font-semibold uppercase tracking-widest text-department">
        Error 404
      </span>
      <h1 className="mt-4 text-5xl font-extrabold tracking-tight text-white sm:text-7xl">
        Route Not Found
      </h1>
      <p className="mt-6 max-w-md text-muted-foreground">
        The page you&apos;re looking for doesn&apos;t exist, or you don&apos;t have clearance to
        view it.
      </p>
      <Link
        href="/"
        className="mt-8 rounded-md bg-white px-6 py-3 text-sm font-semibold text-black transition-colors hover:bg-gray-200"
      >
        Return Home
      </Link>
    </main>
  );
}
