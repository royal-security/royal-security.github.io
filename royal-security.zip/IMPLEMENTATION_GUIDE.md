# Phase 13.1: Audit Log Viewer — Implementation Guide

## What This Adds

A read-only, founder-only audit log viewer at `/admin/audit-log` that displays all admin actions taken in the system, with optional filtering and pagination.

## Files Included

| File | Purpose |
|---|---|
| `lib/audit-read.ts` | Helper functions to fetch and format audit logs (read-only) |
| `app/admin/audit-log/page.tsx` | The audit log page (founder-only) |
| `app/admin/layout.tsx` | **UPDATED** — adds "Audit Log" link to nav |

## Installation Steps

### 1. Copy the files into your project

```cmd
copy lib\audit-read.ts F:\Royal-enterprise\royal-security\lib\
copy app\admin\audit-log\page.tsx F:\Royal-enterprise\royal-security\app\admin\audit-log\
copy app\admin\layout.tsx F:\Royal-enterprise\royal-security\app\admin\
```

(The `app/admin/audit-log/` folder will be created automatically if it doesn't exist.)

### 2. No database changes needed

The `audit_log` table already exists from Phase 13 (you ran that SQL earlier). No new migrations required.

### 3. Test locally

```cmd
npm run dev
```

Then:
- Sign in as a founder user (metadata.role = "founder")
- Navigate to `/admin`
- You should see "Audit Log" link in the sidebar (founder-only)
- Click it and confirm the page loads (empty initially if no actions logged yet)
- Try creating a blog post from `/admin/blog` — it should appear in the audit log immediately

### 4. Type-check

```cmd
npx tsc --noEmit
```

Should return 0 errors.

## How It Works

### Filtering

Three optional filters:
- **Action**: Dropdown of all distinct actions (e.g. "Created blog post", "Updated CTF module")
- **Actor**: Text search by user ID (Clerk ID)
- **Table**: Filter by target table name (e.g. "blog_posts", "writeups")

Filters are optional — remove any or all to see the full audit log.

### Pagination

20 entries per page. Use Prev/Next buttons to navigate.

### Visibility

Each log entry shows:
- **Action**: Human-readable label (e.g. "Updated blog post") in green
- **Actor**: Clerk user ID (truncated)
- **Target**: Table name + first 8 chars of row ID
- **Changes**: Truncated before/after values (or "created", "deleted", "no change")
- **When**: Full timestamp

The "Changes" column shows simplified diffs so you can quickly spot what was actually modified without needing to open every row.

## Security Notes

- Audit logs are **immutable** — `audit_log` table has no UPDATE/DELETE policies at all
- Reads are **founder-only** — page checks `requireRolePage(["founder"])`
- Uses **service-role client** (`utils/supabase/admin.ts`) — no client-side RLS bypass
- No data leaves the admin dashboard — no export/download feature yet (can add later if needed)

## What Gets Logged

Every admin action automatically logs itself via `lib/audit.ts::logAudit()`:
- Blog post CRUD (already logged in your actions.ts)
- Writeup CRUD (already logged)
- Team member CRUD (already logged)
- CTF module CRUD (already logged)
- Site stats updates (already logged)
- Vulnerability report status changes (already logged)
- PDF uploads (already logged)
- Billing linking (already logged)

Each entry captures: who, what action, what table, what ID, before state, after state, when.

## Formatting Helpers

The `lib/audit-read.ts` file exports three helpers:

**`humanizeAction(action: string)`** — converts DB action names to readable labels
- `blog_posts.update` → "Updated blog post"
- `ctf_modules.create` → "Created CTF module"
- etc.

**`formatChange(before, after)`** — truncates JSON diffs to ~50 chars per side
- Returns `"no change"` if identical
- Returns `"created: {...}..."` if before is null
- Returns `"deleted"` if after is null
- Otherwise shows `"old value... → new value..."`

**`getDistinctActions()`** — fetches all unique action names from the log for the filter dropdown

## Future Enhancements

- Add **export to CSV** button for compliance audits
- Add **time range filter** (before/after date)
- Add **audit log retention policy viewer** (e.g. "logs older than 90 days are auto-deleted")
- Add **action detail modal** — click a row to see full before/after JSON
- Add **real-time notifications** when someone makes a critical action (Phase 12 prerequisite)

## Troubleshooting

**Audit log page shows no entries**
- Create a blog post or other content from `/admin` — it should appear immediately
- If still nothing, check Supabase Dashboard > SQL Editor and run:
  ```sql
  select count(*) from audit_log;
  ```

**"Cannot find module '@/lib/audit-read'"**
- Make sure `lib/audit-read.ts` was copied to the right place
- Run `npx tsc --noEmit` to see the exact import error

**Filters aren't working**
- Confirm the form's `name` attributes match the URL params: `action`, `actor_id`, `targetTable`
- The filter form is a standard `<form>` — it POSTs to itself and re-renders with filtered results

---

## Next Phase

Once this is working, move to **Phase 13.2: Email Notifications** (2.5 hours).

That will notify admins when applications, contact messages, or critical vulnerabilities arrive — right now they're silently inserted into the database with no one knowing.
