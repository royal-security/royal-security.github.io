-- Royal Security Enterprise Platform — Database Schema
-- Run this in the Supabase SQL Editor (Project > SQL Editor > New query > paste > Run).
-- Every table referenced by the Next.js code in this repo is created here.

-- =========================================================
-- 1. team_members — powers /about org chart
-- =========================================================
create table if not exists team_members (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  role text not null,
  department text,
  sort_order int default 0,
  created_at timestamptz default now()
);

alter table team_members enable row level security;

create policy "Team members are publicly readable"
  on team_members for select
  using (true);

-- =========================================================
-- 2. blog_posts — powers /blog, /blog/[slug], and app/actions.ts::createBlogPost
-- =========================================================
create table if not exists blog_posts (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  slug text not null unique,
  category text not null check (category in ('Announcements', 'Tutorials', 'Research')),
  content text not null,
  author_id text not null, -- Clerk userId (text, not uuid)
  created_at timestamptz default now()
);

alter table blog_posts enable row level security;

create policy "Blog posts are publicly readable"
  on blog_posts for select
  using (true);

-- Inserts/updates go through the Server Action, which already enforces
-- requireAdmin() via Clerk before calling Supabase, so no INSERT/UPDATE policy
-- is granted to the anon/authenticated role here — the server uses the
-- service role implicitly via the trusted server-side Supabase client.

-- =========================================================
-- 3. writeups — powers /writeups, /writeups/[slug]
-- =========================================================
create table if not exists writeups (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  slug text not null unique,
  challenge_name text not null,
  difficulty text not null check (difficulty in ('Beginner', 'Intermediate', 'Advanced')),
  category text not null,
  content text not null,
  is_gated boolean default false, -- true = only visible in /portal/learner, not public /writeups
  created_at timestamptz default now()
);

alter table writeups enable row level security;

create policy "Public writeups are readable by everyone"
  on writeups for select
  using (is_gated = false);

-- =========================================================
-- 4. applications — powers /join (submitApplication server action)
-- =========================================================
create table if not exists applications (
  id uuid primary key default gen_random_uuid(),
  full_name text not null,
  email text not null,
  department_interest text not null,
  experience text not null,
  created_at timestamptz default now()
);

alter table applications enable row level security;
-- No public SELECT policy: applications are write-only from the client's
-- perspective. Only accessible to admins via the Supabase dashboard or a
-- future admin-only server action.

-- =========================================================
-- 5. contact_messages — powers /contact (submitContactMessage server action)
-- =========================================================
create table if not exists contact_messages (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  email text not null,
  message text not null,
  created_at timestamptz default now()
);

alter table contact_messages enable row level security;
-- Write-only from the client's perspective, same rationale as applications.

-- =========================================================
-- 6. ctf_modules — powers /portal/learner CTF Tracker + updateCTFModule action
-- =========================================================
create table if not exists ctf_modules (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  category text not null,
  difficulty text not null check (difficulty in ('Beginner', 'Intermediate', 'Advanced')),
  content text not null,
  created_at timestamptz default now()
);

alter table ctf_modules enable row level security;

create policy "Authenticated users can read CTF modules"
  on ctf_modules for select
  using (auth.role() = 'authenticated');

-- =========================================================
-- 7. vulnerability_reports — powers /portal/client
-- Section 8.2: org_id must match the requesting user's Clerk organization.
-- Clerk's org_id is passed manually by the server action (trusted server
-- context), and RLS additionally protects against direct table access if the
-- anon/authenticated key is ever exposed to a client-side query.
-- =========================================================
create table if not exists vulnerability_reports (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  severity text not null check (severity in ('Critical', 'High', 'Medium', 'Low')),
  description text not null,
  affected_asset text not null,
  org_id text not null, -- Clerk Organization ID
  created_at timestamptz default now()
);

alter table vulnerability_reports enable row level security;

-- Requires the Clerk JWT template to expose org_id as a custom claim so that
-- this can be checked via auth.jwt() ->> 'org_id'. Configure this in
-- Clerk Dashboard > JWT Templates > Supabase.
create policy "Org members can read their own org's reports"
  on vulnerability_reports for select
  using (org_id = (auth.jwt() ->> 'org_id'));

-- =========================================================
-- 8. site_config — powers homepage stats block + /api/public/stats
-- =========================================================
create table if not exists site_config (
  id int primary key default 1,
  members_count int default 0,
  ctfs_participated int default 0,
  writeups_published int default 0,
  constraint single_row check (id = 1)
);

alter table site_config enable row level security;

create policy "Site config is publicly readable"
  on site_config for select
  using (true);

insert into site_config (id, members_count, ctfs_participated, writeups_published)
values (1, 0, 0, 0)
on conflict (id) do nothing;

-- =========================================================
-- 9. Storage bucket for Section 8.2 encrypted client audit PDFs
-- =========================================================
insert into storage.buckets (id, name, public)
values ('audit-reports', 'audit-reports', false)
on conflict (id) do nothing;

-- Object metadata must include an "org_id" custom field matching the
-- uploading org, set at upload time by the server-side upload action.
create policy "Org members can read their own org's audit reports"
  on storage.objects for select
  using (
    bucket_id = 'audit-reports'
    and (metadata ->> 'org_id') = (auth.jwt() ->> 'org_id')
  );
