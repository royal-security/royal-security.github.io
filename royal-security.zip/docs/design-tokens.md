# Design Tokens

## Typography
- Font: Inter
- Headings: Bold, tight tracking (-0.02em)
- Body: Regular, relaxed line-height (1.6)

## Colors
- Background: Navy (#0B1120)
- Global Accent: Cyan (#00A8FF)

### Department Colors
- Red Team: #FF3B30
- Blue Team: #007AFF
- Web Security: #34C759
