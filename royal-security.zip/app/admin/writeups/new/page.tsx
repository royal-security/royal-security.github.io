import { WriteupForm } from "@/components/admin/WriteupForm";
import { requirePermissionPage } from "@/lib/roles-page";
import { PERMISSIONS } from "@/lib/roles";

export default async function NewWriteupPage() {
  const claims = await requirePermissionPage(PERMISSIONS.WRITEUPS_WRITE);
  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">New Writeup</h1>
      <WriteupForm lockedDepartment={claims.role === "dept_lead" ? claims.department : null} />
    </div>
  );
}
