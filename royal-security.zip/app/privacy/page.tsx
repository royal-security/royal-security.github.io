import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Privacy Policy",
  description: "How Royal Security collects and handles data.",
};

export default function PrivacyPage() {
  return (
    <main className="container mx-auto max-w-3xl px-4 py-24 text-muted-foreground">
      <h1 className="text-4xl font-extrabold tracking-tight text-white">Privacy Policy</h1>
      <p className="mt-2 text-sm">Last updated: {new Date().toLocaleDateString()}</p>

      <section className="mt-8 space-y-4">
        <h2 className="text-xl font-bold text-white">Data We Collect</h2>
        <p>
          We collect account information you provide via Clerk (name, email, authentication
          metadata), application and contact form submissions, and operational telemetry such as
          CTF progress and vulnerability report data submitted through the client portal.
        </p>

        <h2 className="text-xl font-bold text-white">Cookies &amp; Sessions</h2>
        <p>
          Authentication session cookies are set by Clerk and Supabase to keep you signed in
          across page loads. These cookies are required for the portal to function and are never
          used for third-party advertising.
        </p>

        <h2 className="text-xl font-bold text-white">Data Isolation</h2>
        <p>
          Client organization data is isolated at the database level using Supabase Row Level
          Security. Members of one organization cannot access records belonging to another.
        </p>

        <h2 className="text-xl font-bold text-white">Your Rights (GDPR)</h2>
        <p>
          You may request access to, correction of, or deletion of your personal data at any time
          by contacting us through the <a href="/contact" className="underline">contact page</a>.
        </p>
      </section>
    </main>
  );
}
