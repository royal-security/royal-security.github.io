"use client";

import { useState, useTransition } from "react";
import { getReportDownloadUrl } from "@/app/actions";

type Report = {
  id: string;
  title: string;
  severity: "Critical" | "High" | "Medium" | "Low";
  status: "Open" | "In Remediation" | "Resolved";
  affected_asset: string;
  report_path: string | null;
  created_at: string;
};

const severityColor: Record<Report["severity"], string> = {
  Critical: "bg-red-500/20 text-red-400 border-red-500/40",
  High: "bg-orange-500/20 text-orange-400 border-orange-500/40",
  Medium: "bg-yellow-500/20 text-yellow-400 border-yellow-500/40",
  Low: "bg-blue-500/20 text-blue-400 border-blue-500/40",
};

const statusColor: Record<Report["status"], string> = {
  Open: "bg-red-500/20 text-red-400",
  "In Remediation": "bg-yellow-500/20 text-yellow-400",
  Resolved: "bg-emerald-500/20 text-emerald-400",
};

function DownloadButton({ reportId }: { reportId: string }) {
  const [isPending, startTransition] = useTransition();
  const [error, setError] = useState<string | null>(null);

  function handleDownload() {
    setError(null);
    startTransition(async () => {
      try {
        const url = await getReportDownloadUrl(reportId);
        // Signed URL expires in 60s — open immediately rather than storing it.
        window.open(url, "_blank", "noopener,noreferrer");
      } catch (err) {
        setError(err instanceof Error ? err.message : "Download failed");
      }
    });
  }

  return (
    <div>
      <button
        onClick={handleDownload}
        disabled={isPending}
        className="text-xs font-semibold text-[#00A8FF] hover:underline disabled:opacity-50"
      >
        {isPending ? "Generating link…" : "Download PDF"}
      </button>
      {error && <p className="text-xs text-red-400 mt-1">{error}</p>}
    </div>
  );
}

export function ReportsTable({ reports }: { reports: Report[] }) {
  if (reports.length === 0) {
    return (
      <div className="p-6 bg-slate-900 border border-slate-800 rounded-lg">
        <p className="text-gray-400">No vulnerability reports submitted yet.</p>
      </div>
    );
  }

  return (
    <div className="overflow-x-auto rounded-lg border border-slate-800">
      <table className="w-full text-sm">
        <thead className="bg-slate-900 text-gray-400">
          <tr>
            <th className="text-left p-3">Title</th>
            <th className="text-left p-3">Severity</th>
            <th className="text-left p-3">Status</th>
            <th className="text-left p-3">Asset</th>
            <th className="text-left p-3">Submitted</th>
            <th className="text-left p-3">Report</th>
          </tr>
        </thead>
        <tbody>
          {reports.map((r) => (
            <tr key={r.id} className="border-t border-slate-800 bg-slate-950/50">
              <td className="p-3 text-white font-medium">{r.title}</td>
              <td className="p-3">
                <span className={`inline-block px-2 py-1 rounded border text-xs font-semibold ${severityColor[r.severity]}`}>
                  {r.severity}
                </span>
              </td>
              <td className="p-3">
                <span className={`inline-block px-2 py-1 rounded text-xs font-semibold ${statusColor[r.status]}`}>
                  {r.status}
                </span>
              </td>
              <td className="p-3 text-gray-400">{r.affected_asset}</td>
              <td className="p-3 text-gray-500 text-xs">
                {new Date(r.created_at).toLocaleDateString()}
              </td>
              <td className="p-3">
                {r.report_path ? (
                  <DownloadButton reportId={r.id} />
                ) : (
                  <span className="text-xs text-gray-600">Not yet available</span>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
