import { auth } from "@clerk/nextjs/server";
import { redirect } from "next/navigation";
import { can, normalizeRole, type Permission } from "@/lib/roles";

/**
 * Shared server-component guard for admin pages (Phase 11).
 * Redirects unauthenticated users to /sign-in and users without the
 * required permission back to the dashboard. Returns the normalized
 * role and department so pages can apply dept_lead scoping.
 */
export async function getAdminContext(permission?: Permission) {
  const { userId, sessionClaims } = await auth();
  const metadata = (sessionClaims?.metadata ?? {}) as {
    role?: string;
    department?: string;
  };
  const role = normalizeRole(metadata.role);

  if (!userId) redirect("/sign-in");
  if (permission && !can(role, permission)) redirect("/admin");

  return {
    userId,
    role,
    department: metadata.department?.trim() ? metadata.department.trim() : null,
  };
}

/** Render a Supabase timestamptz in a compact, human-readable form. */
export function formatDate(value: string | null | undefined): string {
  if (!value) return "—";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "—";
  return date.toLocaleString("en-US", {
    year: "numeric",
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}
