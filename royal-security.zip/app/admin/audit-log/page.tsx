import Link from "next/link";
import { getAuditLogs, getDistinctActions, humanizeAction, formatChange } from "@/lib/audit-read";
import { requirePermissionPage } from "@/lib/roles-page";
import { PERMISSIONS } from "@/lib/roles";

export const dynamic = "force-dynamic";

type SearchParams = {
  action?: string;
  actor_id?: string;
  entity?: string;
  page?: string;
};

export default async function AdminAuditLogPage({
  searchParams,
}: {
  searchParams: Promise<SearchParams>;
}) {
  await requirePermissionPage(PERMISSIONS.AUDIT_READ);

  const params = await searchParams;
  const page = parseInt(params.page ?? "0");
  const limit = 20;
  const offset = page * limit;

  const [auditResult, actions] = await Promise.all([
    getAuditLogs({
      action: params.action,
      actor_id: params.actor_id,
      entity: params.entity,
      limit,
      offset,
    }),
    getDistinctActions(),
  ]);

  const totalPages = Math.ceil(auditResult.total / limit);
  const queryString = new URLSearchParams({
    ...(params.action && { action: params.action }),
    ...(params.actor_id && { actor_id: params.actor_id }),
    ...(params.entity && { entity: params.entity }),
  }).toString();

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-2xl font-bold mb-6">Audit Log</h1>
        <p className="text-sm text-gray-400 mb-4">
          Complete record of all admin actions. Newest first.
        </p>

        <form method="get" className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <div>
            <label className="text-sm text-gray-400 block mb-1">Filter by action</label>
            <select
              name="action"
              defaultValue={params.action ?? ""}
              className="p-2 rounded bg-gray-800 border border-gray-700 text-white w-full text-sm"
            >
              <option value="">All actions</option>
              {actions.map((a) => (
                <option key={a} value={a}>
                  {humanizeAction(a)}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="text-sm text-gray-400 block mb-1">Filter by actor</label>
            <input
              name="actor_id"
              type="text"
              placeholder="User ID or email"
              defaultValue={params.actor_id ?? ""}
              className="p-2 rounded bg-gray-800 border border-gray-700 text-white w-full text-sm"
            />
          </div>

          <div>
            <label className="text-sm text-gray-400 block mb-1">Filter by entity</label>
            <input
              name="entity"
              type="text"
              placeholder="e.g. blog_posts"
              defaultValue={params.entity ?? ""}
              className="p-2 rounded bg-gray-800 border border-gray-700 text-white w-full text-sm"
            />
          </div>

          <button
            type="submit"
            className="md:col-span-3 px-4 py-2 bg-emerald-600 hover:bg-emerald-500 rounded font-semibold text-sm transition w-fit"
          >
            Apply Filters
          </button>

          {(params.action || params.actor_id || params.entity) && (
            <Link
              href="/admin/audit-log"
              className="md:col-span-3 px-4 py-2 text-sm text-gray-400 hover:text-white underline"
            >
              Clear filters
            </Link>
          )}
        </form>
      </div>

      <div className="mb-6 text-xs text-gray-500">
        Showing {auditResult.entries.length === 0 ? 0 : offset + 1}–
        {Math.min(offset + limit, auditResult.total)} of {auditResult.total} entries
      </div>

      <div className="rounded-lg border border-gray-800 overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-gray-900 text-gray-400">
            <tr>
              <th className="text-left p-3">Action</th>
              <th className="text-left p-3">Actor</th>
              <th className="text-left p-3">Target</th>
              <th className="text-left p-3">Changes</th>
              <th className="text-left p-3">When</th>
            </tr>
          </thead>
          <tbody>
            {auditResult.entries.length === 0 ? (
              <tr>
                <td colSpan={5} className="p-6 text-center text-gray-500">
                  No audit entries found.
                </td>
              </tr>
            ) : (
              auditResult.entries.map((entry) => (
                <tr key={entry.id} className="border-t border-gray-800 hover:bg-gray-900/50">
                  <td className="p-3">
                    <span className="text-emerald-400 font-medium">
                      {humanizeAction(entry.action)}
                    </span>
                  </td>
                  <td className="p-3 text-gray-400 text-xs">{entry.actor_id}</td>
                  <td className="p-3 text-gray-400 text-xs">
                    {entry.entity}
                    {entry.entity_id ? ` (${entry.entity_id.slice(0, 8)})` : ""}
                  </td>
                  <td className="p-3 text-gray-300 font-mono text-xs max-w-xs truncate">
                    {formatChange(entry.before, entry.after)}
                  </td>
                  <td className="p-3 text-gray-500 text-xs">
                    {new Date(entry.created_at).toLocaleString()}
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {totalPages > 1 && (
        <div className="flex items-center justify-between mt-6">
          <div className="text-sm text-gray-400">
            Page {page + 1} of {totalPages}
          </div>
          <div className="space-x-2">
            {page > 0 && (
              <Link
                href={`/admin/audit-log?${queryString}&page=${page - 1}`}
                className="px-3 py-1 bg-gray-800 hover:bg-gray-700 rounded text-sm transition"
              >
                ← Prev
              </Link>
            )}
            {page < totalPages - 1 && (
              <Link
                href={`/admin/audit-log?${queryString}&page=${page + 1}`}
                className="px-3 py-1 bg-gray-800 hover:bg-gray-700 rounded text-sm transition"
              >
                Next →
              </Link>
            )}
          </div>
        </div>
      )}

      <p className="text-xs text-gray-600 mt-6">
        Note: This view is read-only, gated behind the AUDIT_READ permission (founder by
        default). Audit logs are immutable and retained indefinitely for compliance.
      </p>
    </div>
  );
}
