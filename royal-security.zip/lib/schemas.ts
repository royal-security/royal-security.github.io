import { z } from "zod";

// Extracted from app/actions.ts so they're unit-testable — a "use server"
// file can only export async functions, not plain values like these, so
// they can't live there and also be imported by a Vitest file directly.
// app/actions.ts imports these instead of redefining them (see the patch doc).

export const vulnerabilitySchema = z.object({
  title: z.string().min(5),
  severity: z.enum(["Critical", "High", "Medium", "Low"]),
  description: z.string().min(20),
  affected_asset: z.string().min(2),
});

export const ctfModuleSchema = z.object({
  module_id: z.string().min(1),
  title: z.string().min(3),
  category: z.string().min(2),
  difficulty: z.enum(["Beginner", "Intermediate", "Advanced"]),
  content: z.string().min(10),
});

export const applicationSchema = z.object({
  full_name: z.string().min(2),
  email: z.string().email(),
  department_interest: z.string().min(2),
  experience: z.string().min(10),
});

export const contactSchema = z.object({
  name: z.string().min(2),
  email: z.string().email(),
  message: z.string().min(10),
});

export const writeupSchema = z.object({
  title: z.string().min(3),
  slug: z.string().min(2),
  challenge_name: z.string().min(2),
  difficulty: z.enum(["Beginner", "Intermediate", "Advanced"]),
  category: z.string().min(2),
  content: z.string().min(10),
  is_gated: z.boolean(),
});

export const teamMemberSchema = z.object({
  name: z.string().min(2),
  role: z.string().min(2),
  department: z.string().optional(),
  sort_order: z.coerce.number().int().default(0),
});

export const siteConfigSchema = z.object({
  members_count: z.coerce.number().int().min(0),
  ctfs_participated: z.coerce.number().int().min(0),
  writeups_published: z.coerce.number().int().min(0),
});
