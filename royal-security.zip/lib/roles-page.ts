import { auth } from "@clerk/nextjs/server";
import { redirect } from "next/navigation";
import { can, normalizeRole, type Permission, type Role } from "@/lib/roles";

/**
 * Page-level equivalent of the requirePermission() helper in app/actions.ts.
 * Use this in every admin page's Server Component body instead of hand-rolling
 * an auth() + role check each time — that duplication is exactly what let
 * this admin console drift out of sync with lib/roles.ts in the first place.
 */
export async function requirePermissionPage(
  permission: Permission,
  redirectTo = "/admin"
): Promise<{ userId: string; role: Role; department: string | null }> {
  const { userId, sessionClaims } = await auth();
  if (!userId) redirect("/sign-in");

  const metadata = (sessionClaims?.metadata ?? {}) as { role?: string; department?: string };
  const role = normalizeRole(metadata.role);

  if (!can(role, permission)) redirect(redirectTo);

  return {
    userId,
    role,
    department: metadata.department?.trim() ? metadata.department.trim() : null,
  };
}
