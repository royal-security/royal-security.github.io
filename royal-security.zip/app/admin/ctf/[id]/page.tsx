import { notFound } from "next/navigation";
import { createAdminClient } from "@/utils/supabase/admin";
import { CTFForm } from "@/components/admin/CTFForm";
import { requirePermissionPage } from "@/lib/roles-page";
import { PERMISSIONS } from "@/lib/roles";

export default async function EditCTFModulePage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const claims = await requirePermissionPage(PERMISSIONS.CTF_WRITE);
  const { id } = await params;
  const supabase = createAdminClient();
  if (!supabase) return [];
  const { data: mod } = await supabase
    .from("ctf_modules")
    .select("id, title, category, difficulty, content, department")
    .eq("id", id)
    .single();

  if (!mod) notFound();
  if (claims.role === "dept_lead" && mod.department !== claims.department) notFound();

  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">Edit CTF Module</h1>
      <CTFForm mod={mod} lockedDepartment={claims.role === "dept_lead" ? claims.department : null} />
    </div>
  );
}
