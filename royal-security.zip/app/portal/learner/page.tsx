import { currentUser } from "@clerk/nextjs/server";

export default async function LearnerPortal() {
  let user;
try {
  user = await currentUser();
} catch (err) {
  console.error("currentUser() failed:", err);
  throw err;
}
  return (
    <div className="space-y-8">
      {/* Welcome Banner */}
      <div className="p-6 rounded-xl border border-gray-800 bg-gray-900/40">
        <h1 className="text-3xl font-bold text-[var(--accent)]">
          Welcome back, {user?.firstName || 'Cadet'}!
        </h1>
        <p className="text-gray-400 mt-2">
          Track your CTF progress, operational rank, and departmental training paths.
        </p>
      </div>

      {/* Telemetry Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="p-6 rounded-lg border border-gray-800 bg-gray-900/20">
          <h2 className="text-gray-400 text-sm font-semibold">Active Department</h2>
          <p className="text-2xl font-bold text-white mt-2">Red Team / Web Sec</p>
        </div>
        <div className="p-6 rounded-lg border border-gray-800 bg-gray-900/20">
          <h2 className="text-gray-400 text-sm font-semibold">CTF Challenges Solved</h2>
          <p className="text-2xl font-bold text-[#34C759] mt-2">42 / 100</p>
        </div>
        <div className="p-6 rounded-lg border border-gray-800 bg-gray-900/20">
          <h2 className="text-gray-400 text-sm font-semibold">Global Rank</h2>
          <p className="text-2xl font-bold text-[var(--accent)] mt-2">#14</p>
        </div>
      </div>

      {/* Module Progress List */}
      <div className="p-6 rounded-xl border border-gray-800 bg-gray-900/40">
        <h2 className="text-xl font-bold mb-4">Assigned Training Modules</h2>
        <div className="space-y-4">
          <div className="p-4 rounded border border-gray-800 bg-gray-900/60 flex items-center justify-between">
            <div>
              <p className="font-semibold">Web Exploitation: SQL Injection Deep Dive</p>
              <p className="text-xs text-gray-400">Category: Web Security • Difficulty: Intermediate</p>
            </div>
            <span className="px-3 py-1 bg-[#34C759]/20 text-[#34C759] text-xs font-semibold rounded-full border border-[#34C759]/30">
              Completed
            </span>
          </div>
          <div className="p-4 rounded border border-gray-800 bg-gray-900/60 flex items-center justify-between">
            <div>
              <p className="font-semibold">Network Packet Analysis & WireShark</p>
              <p className="text-xs text-gray-400">Category: Network Security • Difficulty: Beginner</p>
            </div>
            <span className="px-3 py-1 bg-[var(--accent)]/20 text-[var(--accent)] text-xs font-semibold rounded-full border border-[var(--accent)]/30">
              In Progress
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}