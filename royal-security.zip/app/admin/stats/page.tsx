import { createAdminClient } from "@/utils/supabase/admin";
import { updateSiteConfig } from "@/app/actions";
import { requirePermissionPage } from "@/lib/roles-page";
import { PERMISSIONS } from "@/lib/roles";

export const dynamic = "force-dynamic";

const inputClass = "p-2 rounded bg-gray-800 border border-gray-700 text-white w-full";

async function getConfig() {
  const supabase = createAdminClient();
  if (!supabase) return { members_count: 0, ctfs_participated: 0, writeups_published: 0 };
  const { data } = await supabase
    .from("site_config")
    .select("members_count, ctfs_participated, writeups_published")
    .eq("id", 1)
    .single();
  return data ?? { members_count: 0, ctfs_participated: 0, writeups_published: 0 };
}

export default async function AdminStatsPage() {
  await requirePermissionPage(PERMISSIONS.SITE_CONFIG_WRITE);
  const config = await getConfig();

  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">Site Stats</h1>
      <p className="text-sm text-gray-400 mb-6">
        These numbers power the homepage stats block and the public{" "}
        <code className="text-gray-300">/api/public/stats</code> endpoint.
      </p>

      <form action={updateSiteConfig} className="grid gap-4 max-w-sm p-6 rounded-lg border border-gray-800 bg-gray-900/50">
        <div>
          <label className="text-sm text-gray-400 mb-1 block">Members Count</label>
          <input
            name="members_count"
            type="number"
            min={0}
            defaultValue={config.members_count}
            required
            className={inputClass}
          />
        </div>
        <div>
          <label className="text-sm text-gray-400 mb-1 block">CTFs Participated</label>
          <input
            name="ctfs_participated"
            type="number"
            min={0}
            defaultValue={config.ctfs_participated}
            required
            className={inputClass}
          />
        </div>
        <div>
          <label className="text-sm text-gray-400 mb-1 block">Writeups Published</label>
          <input
            name="writeups_published"
            type="number"
            min={0}
            defaultValue={config.writeups_published}
            required
            className={inputClass}
          />
        </div>
        <button
          type="submit"
          className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 rounded font-semibold transition w-fit"
        >
          Save
        </button>
      </form>
    </div>
  );
}
