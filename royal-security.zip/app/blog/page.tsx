import type { Metadata } from "next";
import Link from "next/link";
import { createClient } from "@/utils/supabase/server";
import { Card, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

export const metadata: Metadata = {
  title: "Blog",
  description: "Announcements, tutorials, and research from Royal Security.",
};

export const revalidate = 300;

type BlogPost = {
  id: string;
  title: string;
  slug: string;
  category: "Announcements" | "Tutorials" | "Research";
  created_at: string;
};

async function getPosts(): Promise<BlogPost[]> {
  const supabase = await createClient();
  const { data, error } = await supabase
    .from("blog_posts")
    .select("id, title, slug, category, created_at")
    .order("created_at", { ascending: false });

  if (error || !data) return [];
  return data as BlogPost[];
}

export default async function BlogIndexPage({
  searchParams,
}: {
  searchParams: Promise<{ category?: string }>;
}) {
  const { category } = await searchParams;
  const posts = await getPosts();
  const filtered = category ? posts.filter((p) => p.category === category) : posts;
  const categories = ["Announcements", "Tutorials", "Research"];

  return (
    <main className="container mx-auto px-4 py-24">
      <h1 className="text-4xl font-extrabold tracking-tight text-white sm:text-6xl">Blog</h1>

      <div className="mt-6 flex flex-wrap gap-2">
        <Link href="/blog">
          <Badge variant={!category ? "default" : "outline"}>All</Badge>
        </Link>
        {categories.map((c) => (
          <Link key={c} href={`/blog?category=${c}`}>
            <Badge variant={category === c ? "default" : "outline"}>{c}</Badge>
          </Link>
        ))}
      </div>

      <div className="mt-8 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {filtered.length === 0 && (
          <p className="text-sm text-muted-foreground">
            No posts yet. Publish one from the admin dashboard.
          </p>
        )}
        {filtered.map((post) => (
          <Link key={post.id} href={`/blog/${post.slug}`}>
            <Card className="h-full border-gray-800 bg-card/50 transition-colors hover:border-department">
              <CardHeader>
                <Badge variant="outline" className="w-fit">
                  {post.category}
                </Badge>
                <CardTitle className="text-white">{post.title}</CardTitle>
                <CardDescription>
                  {new Date(post.created_at).toLocaleDateString()}
                </CardDescription>
              </CardHeader>
            </Card>
          </Link>
        ))}
      </div>
    </main>
  );
}
