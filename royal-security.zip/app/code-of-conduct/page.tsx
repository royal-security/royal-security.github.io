import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Code of Conduct",
  description: "Ethical behavior rules required of all Royal Security members.",
};

const rules = [
  "Only test systems you are explicitly authorized to test. Unauthorized access is grounds for immediate removal.",
  "Treat every member and client with respect regardless of skill level, background, or department.",
  "Never share client vulnerability data, credentials, or internal training materials outside the organization.",
  "Report security issues in our own platform responsibly and privately, not publicly.",
  "Give credit where it's due — plagiarizing writeups or research is not tolerated.",
];

export default function CodeOfConductPage() {
  return (
    <main className="container mx-auto max-w-3xl px-4 py-24">
      <h1 className="text-4xl font-extrabold tracking-tight text-white">Code of Conduct</h1>
      <p className="mt-4 text-muted-foreground">
        Membership in Royal Security is a privilege bound to ethical practice. All members agree
        to the following:
      </p>
      <ol className="mt-8 space-y-4">
        {rules.map((rule, i) => (
          <li key={rule} className="flex gap-3 text-muted-foreground">
            <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-department text-xs font-bold text-black">
              {i + 1}
            </span>
            {rule}
          </li>
        ))}
      </ol>
    </main>
  );
}
