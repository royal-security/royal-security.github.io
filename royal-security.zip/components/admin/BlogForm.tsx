"use client";

import { useRouter } from "next/navigation";
import { createBlogPost, updateBlogPost } from "@/app/actions";

const CATEGORIES = ["Announcements", "Tutorials", "Research"];
const inputClass = "p-2 rounded bg-gray-800 border border-gray-700 text-white w-full";

export function BlogForm({
  post,
}: {
  post?: { id: string; title: string; slug: string; category: string; content: string };
}) {
  const router = useRouter();
  const action = post ? updateBlogPost : createBlogPost;

  async function handleSubmit(formData: FormData) {
    await action(formData);
    router.push("/admin/blog");
  }

  return (
    <form action={handleSubmit} className="grid gap-4 max-w-2xl">
      {post && <input type="hidden" name="id" value={post.id} />}
      <div>
        <label className="text-sm text-gray-400 mb-1 block">Title</label>
        <input name="title" defaultValue={post?.title} required className={inputClass} />
      </div>
      <div>
        <label className="text-sm text-gray-400 mb-1 block">Slug</label>
        <input name="slug" defaultValue={post?.slug} required className={inputClass} />
      </div>
      <div>
        <label className="text-sm text-gray-400 mb-1 block">Category</label>
        <select name="category" defaultValue={post?.category ?? CATEGORIES[0]} required className={inputClass}>
          {CATEGORIES.map((c) => (
            <option key={c} value={c}>
              {c}
            </option>
          ))}
        </select>
      </div>
      <div>
        <label className="text-sm text-gray-400 mb-1 block">Content</label>
        <textarea
          name="content"
          defaultValue={post?.content}
          required
          className={`${inputClass} h-64 font-mono text-sm`}
        />
      </div>
      <button
        type="submit"
        className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 rounded font-semibold transition w-fit"
      >
        {post ? "Save Changes" : "Publish Post"}
      </button>
    </form>
  );
}
