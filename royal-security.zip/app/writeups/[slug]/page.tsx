import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { createClient } from "@/utils/supabase/server";
import { Badge } from "@/components/ui/badge";

export const revalidate = 300;

type Writeup = {
  title: string;
  slug: string;
  challenge_name: string;
  difficulty: string;
  category: string;
  content: string;
  created_at: string;
};

async function getWriteup(slug: string): Promise<Writeup | null> {
  const supabase = await createClient();
  const { data, error } = await supabase
    .from("writeups")
    .select("title, slug, challenge_name, difficulty, category, content, created_at")
    .eq("slug", slug)
    // Explicit filter — a gated writeup must 404 here even if someone knows
    // or guesses its slug. Don't rely on RLS alone as the only gate.
    .eq("is_gated", false)
    .single();

  if (error || !data) return null;
  return data as Writeup;
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const writeup = await getWriteup(slug);
  if (!writeup) return { title: "Writeup Not Found" };
  return { title: `${writeup.challenge_name} — ${writeup.title}` };
}

export default async function WriteupPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const writeup = await getWriteup(slug);
  if (!writeup) notFound();

  return (
    <main className="container mx-auto max-w-3xl px-4 py-24">
      <div className="flex items-center gap-2">
        <Badge variant="outline">{writeup.category}</Badge>
        <Badge variant="outline">{writeup.difficulty}</Badge>
      </div>
      <h1 className="mt-4 text-4xl font-extrabold tracking-tight text-white">
        {writeup.challenge_name}
      </h1>
      <p className="mt-1 text-lg text-muted-foreground">{writeup.title}</p>
      <p className="mt-2 text-sm text-muted-foreground">
        {new Date(writeup.created_at).toLocaleDateString()}
      </p>
      <div className="prose prose-invert mt-8 max-w-none whitespace-pre-wrap text-muted-foreground">
        {writeup.content}
      </div>
    </main>
  );
}
