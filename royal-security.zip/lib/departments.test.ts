import { describe, it, expect } from "vitest";
import { departments, getDepartment, DEFAULT_ACCENT_HSL } from "./departments";

describe("departments", () => {
  it("has exactly 8 departments (Blueprint Section 5.2)", () => {
    expect(departments).toHaveLength(8);
  });

  it("every department has a unique slug", () => {
    const slugs = departments.map((d) => d.slug);
    expect(new Set(slugs).size).toBe(slugs.length);
  });

  it("every department has a unique hex color", () => {
    const hexes = departments.map((d) => d.hex);
    expect(new Set(hexes).size).toBe(hexes.length);
  });

  it("every hex is a valid 6-digit hex color", () => {
    for (const d of departments) {
      expect(d.hex).toMatch(/^#[0-9A-Fa-f]{6}$/);
    }
  });

  it("every department has at least one arsenal tool", () => {
    for (const d of departments) {
      expect(d.arsenal.length).toBeGreaterThan(0);
    }
  });

  it("getDepartment finds an existing slug", () => {
    expect(getDepartment("red-team")?.name).toBe("Red Team");
  });

  it("getDepartment returns undefined for an unknown slug", () => {
    expect(getDepartment("not-a-real-department")).toBeUndefined();
  });

  it("DEFAULT_ACCENT_HSL is a valid HSL triple string", () => {
    expect(DEFAULT_ACCENT_HSL).toMatch(/^[\d.]+ [\d.]+% [\d.]+%$/);
  });
});
