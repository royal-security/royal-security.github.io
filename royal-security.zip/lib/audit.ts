import { headers } from "next/headers";
import { createClient } from "@/utils/supabase/server";
import { createAdminClient } from "@/utils/supabase/admin";
import type { Role } from "./roles";

export type AuditEntry = {
  actorId: string;
  actorRole?: Role;
  action: string;
  entity: string;
  entityId?: string;
  before?: unknown;
  after?: unknown;
};

/**
 * Record a privileged action in audit_log (Phase 13).
 * Uses the service-role client when configured, otherwise the session
 * client. Never throws — auditing must not break the action it records.
 */
export async function logAudit(entry: AuditEntry): Promise<void> {
  try {
    const headerStore = await headers();
    const ip =
      headerStore.get("x-forwarded-for")?.split(",")[0]?.trim() ??
      headerStore.get("x-real-ip") ??
      null;

    const client = createAdminClient() ?? (await createClient());
    await client.from("audit_log").insert({
      actor_id: entry.actorId,
      actor_role: entry.actorRole ?? null,
      action: entry.action,
      entity: entry.entity,
      entity_id: entry.entityId ?? null,
      before: entry.before ? JSON.parse(JSON.stringify(entry.before)) : null,
      after: entry.after ? JSON.parse(JSON.stringify(entry.after)) : null,
      ip,
    });
  } catch {
    // swallow — audit is best-effort
  }
}
