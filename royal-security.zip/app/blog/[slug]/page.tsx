import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { createClient } from "@/utils/supabase/server";
import { Badge } from "@/components/ui/badge";

export const revalidate = 300;

type BlogPost = {
  title: string;
  slug: string;
  category: string;
  content: string;
  created_at: string;
};

async function getPost(slug: string): Promise<BlogPost | null> {
  const supabase = await createClient();
  const { data, error } = await supabase
    .from("blog_posts")
    .select("title, slug, category, content, created_at")
    .eq("slug", slug)
    .single();

  if (error || !data) return null;
  return data as BlogPost;
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const post = await getPost(slug);
  if (!post) return { title: "Post Not Found" };
  return { title: post.title };
}

export default async function BlogPostPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const post = await getPost(slug);
  if (!post) notFound();

  return (
    <main className="container mx-auto max-w-3xl px-4 py-24">
      <Badge variant="outline">{post.category}</Badge>
      <h1 className="mt-4 text-4xl font-extrabold tracking-tight text-white">{post.title}</h1>
      <p className="mt-2 text-sm text-muted-foreground">
        {new Date(post.created_at).toLocaleDateString()}
      </p>
      <div className="prose prose-invert mt-8 max-w-none whitespace-pre-wrap text-muted-foreground">
        {post.content}
      </div>
    </main>
  );
}
