import { departments } from "@/lib/departments";
import { cn } from "@/lib/utils";

export const SELECT_CLASSES =
  "h-8 w-full rounded-lg border border-input bg-transparent px-2.5 text-sm outline-none focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/50 dark:bg-input/30";

/**
 * Native department picker backed by lib/departments.ts so the admin
 * console can never drift from the Dynamic Departmental Chromatic
 * Matrix. Empty value = "General" (any dept_lead can manage nothing
 * general — general records are founder-managed).
 */
export default function DepartmentSelect({
  name = "department",
  defaultValue = "",
  disabled = false,
  required = false,
  className,
}: {
  name?: string;
  defaultValue?: string | null;
  disabled?: boolean;
  required?: boolean;
  className?: string;
}) {
  return (
    <select
      name={name}
      defaultValue={defaultValue ?? ""}
      disabled={disabled}
      required={required}
      className={cn(SELECT_CLASSES, className)}
    >
      <option value="">General</option>
      {departments.map((d) => (
        <option key={d.slug} value={d.name}>
          {d.name}
        </option>
      ))}
    </select>
  );
}
