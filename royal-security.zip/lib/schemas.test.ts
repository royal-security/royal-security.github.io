import { describe, it, expect } from "vitest";
import {
  vulnerabilitySchema,
  ctfModuleSchema,
  applicationSchema,
  contactSchema,
  writeupSchema,
  teamMemberSchema,
  siteConfigSchema,
} from "./schemas";

describe("vulnerabilitySchema", () => {
  it("accepts a valid report", () => {
    const result = vulnerabilitySchema.safeParse({
      title: "SQL injection in /login",
      severity: "Critical",
      description: "Unsanitized input in the username field allows SQLi.",
      affected_asset: "auth-service",
    });
    expect(result.success).toBe(true);
  });

  it("rejects an invalid severity", () => {
    const result = vulnerabilitySchema.safeParse({
      title: "SQL injection in /login",
      severity: "Catastrophic", // not in the enum
      description: "Unsanitized input in the username field allows SQLi.",
      affected_asset: "auth-service",
    });
    expect(result.success).toBe(false);
  });

  it("rejects a description under 20 chars", () => {
    const result = vulnerabilitySchema.safeParse({
      title: "SQL injection",
      severity: "High",
      description: "too short",
      affected_asset: "auth-service",
    });
    expect(result.success).toBe(false);
  });
});

describe("applicationSchema", () => {
  it("rejects an invalid email", () => {
    const result = applicationSchema.safeParse({
      full_name: "Jordan Lee",
      email: "not-an-email",
      department_interest: "Red Team",
      experience: "Two years of CTF competitions and a home lab.",
    });
    expect(result.success).toBe(false);
  });

  it("accepts a valid application", () => {
    const result = applicationSchema.safeParse({
      full_name: "Jordan Lee",
      email: "jordan@example.com",
      department_interest: "Red Team",
      experience: "Two years of CTF competitions and a home lab.",
    });
    expect(result.success).toBe(true);
  });
});

describe("contactSchema", () => {
  it("rejects a message under 10 chars", () => {
    const result = contactSchema.safeParse({
      name: "Sam",
      email: "sam@example.com",
      message: "hi there",
    });
    expect(result.success).toBe(false);
  });
});

describe("ctfModuleSchema", () => {
  it("rejects an invalid difficulty", () => {
    const result = ctfModuleSchema.safeParse({
      module_id: "web-100",
      title: "Basic SQLi",
      category: "Web",
      difficulty: "Impossible",
      content: "Find the flag hidden in the login form.",
    });
    expect(result.success).toBe(false);
  });
});

describe("writeupSchema", () => {
  it("accepts is_gated as a boolean", () => {
    const result = writeupSchema.safeParse({
      title: "Cracking the vault",
      slug: "cracking-the-vault",
      challenge_name: "Vault",
      difficulty: "Advanced",
      category: "Crypto",
      content: "A full walkthrough of the challenge.",
      is_gated: true,
    });
    expect(result.success).toBe(true);
  });
});

describe("teamMemberSchema", () => {
  it("coerces sort_order from a form-data string", () => {
    const result = teamMemberSchema.safeParse({
      name: "Alex Rivera",
      role: "Department Lead",
      sort_order: "3", // FormData values are always strings
    });
    expect(result.success).toBe(true);
    if (result.success) expect(result.data.sort_order).toBe(3);
  });

  it("defaults sort_order to 0 when omitted", () => {
    const result = teamMemberSchema.safeParse({ name: "Alex Rivera", role: "Lead" });
    expect(result.success).toBe(true);
    if (result.success) expect(result.data.sort_order).toBe(0);
  });
});

describe("siteConfigSchema", () => {
  it("rejects negative counts", () => {
    const result = siteConfigSchema.safeParse({
      members_count: -1,
      ctfs_participated: 5,
      writeups_published: 5,
    });
    expect(result.success).toBe(false);
  });
});
