import { createAdminClient } from "@/utils/supabase/admin";
import { ApplicationStatusSelect } from "@/components/admin/ApplicationStatusSelect";
import { requirePermissionPage } from "@/lib/roles-page";
import { PERMISSIONS } from "@/lib/roles";

export const dynamic = "force-dynamic";

async function getApplications() {
  const supabase = createAdminClient();
  if (!supabase) return [];
  const { data } = await supabase
    .from("applications")
    .select("id, full_name, email, department_interest, experience, status, created_at")
    .order("created_at", { ascending: false });
  return data ?? [];
}

export default async function AdminApplicationsPage() {
  await requirePermissionPage(PERMISSIONS.APPLICATIONS_MANAGE);
  const applications = await getApplications();

  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">Applications ({applications.length})</h1>

      <div className="flex flex-col gap-3">
        {applications.map((a) => (
          <div key={a.id} className="p-4 rounded-lg border border-gray-800 bg-gray-900/50">
            <div className="flex items-start justify-between gap-4">
              <div>
                <div className="font-semibold">{a.full_name}</div>
                <div className="text-sm text-gray-400">{a.email}</div>
                <div className="text-sm text-gray-400 mt-1">
                  Interested in: <span className="text-gray-300">{a.department_interest}</span>
                </div>
              </div>
              <div className="flex flex-col items-end gap-2 shrink-0">
                <ApplicationStatusSelect id={a.id} status={a.status ?? "New"} />
                <span className="text-xs text-gray-500">
                  {new Date(a.created_at).toLocaleDateString()}
                </span>
              </div>
            </div>
            <p className="text-sm text-gray-300 mt-3 whitespace-pre-wrap">{a.experience}</p>
          </div>
        ))}
        {applications.length === 0 && (
          <p className="text-center text-gray-500 py-10">No applications yet.</p>
        )}
      </div>
    </div>
  );
}
