import type { Metadata } from "next";
import Link from "next/link";
import SplineBackground from "@/components/SplineBackground";
import { Card, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { departments } from "@/lib/departments";

export const metadata: Metadata = {
  title: "Departments",
  description: "The 8 operational departments of Royal Security.",
};

export default function DepartmentsHubPage() {
  return (
    <main className="relative min-h-screen">
      <SplineBackground />

      <div className="relative z-10 flex flex-col items-center justify-center px-4 pt-24 pb-12 text-center">
        <h1 className="max-w-3xl text-4xl font-extrabold tracking-tight text-white sm:text-6xl">
          Operational Departments
        </h1>
        <p className="mt-6 max-w-2xl text-lg text-muted-foreground">
          Eight specialized divisions, each with its own arsenal, curriculum, and identity.
        </p>
      </div>

      <div className="relative z-10 container mx-auto grid grid-cols-1 gap-6 px-4 pb-24 sm:grid-cols-2 lg:grid-cols-4">
        {departments.map((d) => (
          <Link key={d.slug} href={`/departments/${d.slug}`} className="group">
            <Card
              className="h-full border-gray-800 bg-card/50 backdrop-blur-sm transition-transform duration-300 group-hover:-translate-y-1"
              style={{ boxShadow: `0 0 0 1px ${d.hex}22`, borderColor: `${d.hex}55` }}
            >
              <CardHeader>
                <span
                  className="mb-3 inline-block h-3 w-3 rounded-full"
                  style={{ backgroundColor: d.hex }}
                  aria-hidden="true"
                />
                <CardTitle className="text-white">{d.name}</CardTitle>
                <CardDescription>{d.rationale}</CardDescription>
              </CardHeader>
            </Card>
          </Link>
        ))}
      </div>
    </main>
  );
}
