import type { Metadata } from "next";
import { JoinForm } from "./JoinForm";

export const metadata: Metadata = {
  title: "Join Us",
  description: "Apply to join Royal Security.",
};

const steps = [
  "Submit your application below",
  "Pass a short screening call with a department lead",
  "Complete the onboarding CTF challenge",
  "Get invited to your department's Discord and Learner Portal",
];

const faqs = [
  {
    q: "Do I need prior experience?",
    a: "No. We accept complete beginners as long as you're willing to learn actively.",
  },
  {
    q: "Is membership free?",
    a: "Yes, membership is free for individual learners. Only enterprise client engagements are paid.",
  },
  {
    q: "Can I switch departments later?",
    a: "Yes, members can request a department transfer once they've completed onboarding.",
  },
];

export default function JoinPage() {
  return (
    <main className="container mx-auto px-4 py-24">
      <h1 className="text-4xl font-extrabold tracking-tight text-white sm:text-6xl">Join Us</h1>
      <p className="mt-4 max-w-2xl text-muted-foreground">
        Royal Security welcomes beginners and experienced practitioners alike. Here&apos;s how to
        get started.
      </p>

      <section className="mt-12">
        <h2 className="text-xl font-bold text-white">Application Process</h2>
        <ol className="mt-4 space-y-3">
          {steps.map((step, i) => (
            <li key={step} className="flex gap-3 text-muted-foreground">
              <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-department text-xs font-bold text-black">
                {i + 1}
              </span>
              {step}
            </li>
          ))}
        </ol>
      </section>

      <section className="mt-16 grid gap-12 lg:grid-cols-2">
        <div>
          <h2 className="text-xl font-bold text-white">Application Form</h2>
          <JoinForm />
        </div>

        <div>
          <h2 className="text-xl font-bold text-white">FAQ</h2>
          <div className="mt-4 space-y-4">
            {faqs.map((f) => (
              <details key={f.q} className="rounded-md border border-gray-800 bg-card/50 p-4">
                <summary className="cursor-pointer font-medium text-white">{f.q}</summary>
                <p className="mt-2 text-sm text-muted-foreground">{f.a}</p>
              </details>
            ))}
          </div>
        </div>
      </section>
    </main>
  );
}
