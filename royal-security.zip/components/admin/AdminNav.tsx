"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { cn } from "@/lib/utils";
import {
  LayoutDashboard,
  FileText,
  BookOpen,
  Swords,
  Users,
  Inbox,
  MessageSquare,
  Bug,
  BarChart3,
  ScrollText,
  ExternalLink,
  ShieldHalf,
} from "lucide-react";

export type AdminNavItem = { href: string; label: string };

const ICON_MAP: Record<string, typeof LayoutDashboard> = {
  "/admin": LayoutDashboard,
  "/admin/blog": FileText,
  "/admin/writeups": BookOpen,
  "/admin/ctf": Swords,
  "/admin/team": Users,
  "/admin/applications": Inbox,
  "/admin/messages": MessageSquare,
  "/admin/reports": Bug,
  "/admin/site-stats": BarChart3,
  "/admin/audit": ScrollText,
};

/**
 * Responsive admin navigation. Renders a horizontal scroll strip on
 * mobile and a sticky sidebar on desktop. The item list is filtered by
 * role on the server (see app/admin/layout.tsx).
 */
export default function AdminNav({
  items,
  roleLabel,
  department,
}: {
  items: AdminNavItem[];
  roleLabel: string;
  department: string | null;
}) {
  const pathname = usePathname();

  const links = items.map((item) => {
    const Icon = ICON_MAP[item.href] ?? LayoutDashboard;
    const active = pathname === item.href || pathname.startsWith(item.href + "/");
    return (
      <Link
        key={item.href}
        href={item.href}
        aria-current={active ? "page" : undefined}
        className={cn(
          "flex items-center gap-2.5 rounded-lg px-3 py-2 text-sm font-medium whitespace-nowrap transition-colors",
          active
            ? "bg-primary/10 text-primary ring-1 ring-primary/20"
            : "text-muted-foreground hover:bg-muted hover:text-foreground"
        )}
      >
        <Icon className="size-4 shrink-0" />
        {item.label}
      </Link>
    );
  });

  return (
    <>
      {/* Mobile: horizontal strip */}
      <nav
        aria-label="Admin sections"
        className="-mx-4 mb-6 flex gap-1.5 overflow-x-auto px-4 pb-2 lg:hidden"
      >
        {links}
      </nav>

      {/* Desktop: sticky sidebar */}
      <aside className="sticky top-6 hidden lg:flex lg:flex-col lg:gap-1 lg:self-start">
        <div className="mb-3 flex items-center gap-2.5 rounded-xl border border-border bg-card p-3">
          <span className="flex size-9 items-center justify-center rounded-lg bg-primary/10 text-primary ring-1 ring-primary/20">
            <ShieldHalf className="size-5" />
          </span>
          <div className="min-w-0">
            <p className="truncate text-sm font-semibold leading-tight">Admin Console</p>
            <p className="truncate text-xs text-muted-foreground">
              {roleLabel}
              {department ? ` · ${department}` : ""}
            </p>
          </div>
        </div>
        <nav aria-label="Admin sections" className="flex flex-col gap-1">
          {links}
        </nav>
        <Link
          href="/"
          className="mt-2 flex items-center gap-2.5 rounded-lg px-3 py-2 text-sm font-medium text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
        >
          <ExternalLink className="size-4" />
          View site
        </Link>
      </aside>
    </>
  );
}
