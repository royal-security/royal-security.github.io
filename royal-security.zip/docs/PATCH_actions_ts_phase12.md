# Patch: app/actions.ts (Phase 12 — Notifications)

Three small edits to your existing `app/actions.ts`. Each is a find-and-replace
— find the exact block below and replace it with the version after it.

## 1. Add the import

Find:
```ts
import { requireRole, assertOwnsDepartment } from "@/lib/roles";
import { logAudit } from "@/lib/audit";
import { getStripe } from "@/utils/stripe";
```

Replace with:
```ts
import { requireRole, assertOwnsDepartment } from "@/lib/roles";
import { logAudit } from "@/lib/audit";
import { getStripe } from "@/utils/stripe";
import { notifyNewApplication, notifyNewContactMessage, notifyHighSeverityReport } from "@/lib/email";
```

## 2. submitVulnerabilityReport — notify on Critical/High

Find:
```ts
  if (error) {
    throw new Error("Database error: " + error.message);
  }

  revalidatePath("/portal/client");
  revalidatePath("/");
}

// ACTION 2: Update CTF / Training Module
```

Replace with:
```ts
  if (error) {
    throw new Error("Database error: " + error.message);
  }

  if (parsed.data.severity === "Critical" || parsed.data.severity === "High") {
    await notifyHighSeverityReport({
      title: parsed.data.title,
      severity: parsed.data.severity,
      org_id: orgId,
    });
  }

  revalidatePath("/portal/client");
  revalidatePath("/");
}

// ACTION 2: Update CTF / Training Module
```

## 3. submitApplication — notify client_success

Find:
```ts
  const supabase = await createClient();
  const { error } = await supabase.from("applications").insert(parsed.data);

  if (error) throw new Error("Database error: " + error.message);
}

// ACTION 5: Submit Contact Form Message (/contact) — Section 7.2
```

Replace with:
```ts
  const supabase = await createClient();
  const { error } = await supabase.from("applications").insert(parsed.data);

  if (error) throw new Error("Database error: " + error.message);

  await notifyNewApplication(parsed.data);
}

// ACTION 5: Submit Contact Form Message (/contact) — Section 7.2
```

## 4. submitContactMessage — notify client_success

Find:
```ts
  const supabase = await createClient();
  const { error } = await supabase.from("contact_messages").insert(parsed.data);

  if (error) throw new Error("Database error: " + error.message);
}
```

Replace with:
```ts
  const supabase = await createClient();
  const { error } = await supabase.from("contact_messages").insert(parsed.data);

  if (error) throw new Error("Database error: " + error.message);

  await notifyNewContactMessage(parsed.data);
}
```

---

That's it — no other function changes. `lib/email.ts` (included in this
delivery) fails soft everywhere: missing `RESEND_API_KEY` just logs a warning
and skips sending, so nothing breaks before you've set up Resend.
