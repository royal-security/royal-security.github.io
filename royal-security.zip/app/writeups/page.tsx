import type { Metadata } from "next";
import Link from "next/link";
import { createClient } from "@/utils/supabase/server";
import { Card, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

export const metadata: Metadata = {
  title: "Writeups",
  description: "CTF solutions and vulnerability research from Royal Security.",
};

export const revalidate = 300;

type Writeup = {
  id: string;
  title: string;
  slug: string;
  challenge_name: string;
  difficulty: "Beginner" | "Intermediate" | "Advanced";
  category: string;
  created_at: string;
};

const difficultyColor: Record<string, string> = {
  Beginner: "text-emerald-400",
  Intermediate: "text-amber-400",
  Advanced: "text-red-400",
};

async function getWriteups(): Promise<Writeup[]> {
  const supabase = await createClient();
  const { data, error } = await supabase
    .from("writeups")
    .select("id, title, slug, challenge_name, difficulty, category, created_at")
    // Explicit filter — don't rely on RLS alone to hide gated writeups from
    // the public list. RLS is defense-in-depth here, not the only gate.
    .eq("is_gated", false)
    .order("created_at", { ascending: false });

  if (error || !data) return [];
  return data as Writeup[];
}

export default async function WriteupsIndexPage() {
  const writeups = await getWriteups();

  return (
    <main className="container mx-auto px-4 py-24">
      <h1 className="text-4xl font-extrabold tracking-tight text-white sm:text-6xl">Writeups</h1>
      <p className="mt-4 max-w-2xl text-muted-foreground">
        Public CTF solutions and vulnerability research. Deeper, gated writeups live in the{" "}
        <Link href="/portal/learner" className="underline">
          Learner Portal
        </Link>
        .
      </p>

      <div className="mt-8 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {writeups.length === 0 && (
          <p className="text-sm text-muted-foreground">
            No public writeups yet. Publish one from the admin dashboard.
          </p>
        )}
        {writeups.map((w) => (
          <Link key={w.id} href={`/writeups/${w.slug}`}>
            <Card className="h-full border-gray-800 bg-card/50 transition-colors hover:border-department">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Badge variant="outline">{w.category}</Badge>
                  <span className={`text-xs font-semibold ${difficultyColor[w.difficulty]}`}>
                    {w.difficulty}
                  </span>
                </div>
                <CardTitle className="text-white">{w.challenge_name}</CardTitle>
                <CardDescription>{w.title}</CardDescription>
              </CardHeader>
            </Card>
          </Link>
        ))}
      </div>
    </main>
  );
}
