"use client";

import { useRef } from "react";
import { Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";

/**
 * Delete control for server-action forms. Intercepts the submit, asks
 * for confirmation, then submits. The bound server action must read an
 * `id` field from the FormData (hidden input rendered here).
 */
export default function ConfirmDelete({
  action,
  id,
  label = "Delete",
  confirmText = "Are you sure? This cannot be undone.",
}: {
  action: (formData: FormData) => void | Promise<void>;
  id: string;
  label?: string;
  confirmText?: string;
}) {
  const formRef = useRef<HTMLFormElement>(null);

  return (
    <form
      ref={formRef}
      action={action}
      onSubmit={(event) => {
        if (!window.confirm(confirmText)) {
          event.preventDefault();
        }
      }}
    >
      <input type="hidden" name="id" value={id} />
      <Button type="submit" variant="destructive" size="sm">
        <Trash2 />
        {label}
      </Button>
    </form>
  );
}
