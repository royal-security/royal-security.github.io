"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { auth } from "@clerk/nextjs/server";
import { z } from "zod";
import { createClient } from "@/utils/supabase/server";
import { createAdminClient } from "@/utils/supabase/admin";
import { can, normalizeRole, PERMISSIONS, type Permission, type Role } from "@/lib/roles";
import { logAudit } from "@/lib/audit";
import { rateLimit } from "@/lib/rate-limit";
import { notifyAdmins } from "@/lib/notify";
import { getStripe } from "@/utils/stripe";

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function str(formData: FormData, name: string): string {
  const value = formData.get(name);
  return typeof value === "string" ? value : "";
}

function strOrNull(formData: FormData, name: string): string | null {
  const value = str(formData, name).trim();
  return value.length > 0 ? value : null;
}

/**
 * Enforce a specific permission (Phase 11). Returns the Clerk userId, the
 * normalized role, and the department from publicMetadata (for dept_lead
 * scoping). Throws for unauthorized callers.
 */
async function requirePermission(permission: Permission): Promise<{
  userId: string;
  role: Role;
  department: string | null;
}> {
  const { userId, sessionClaims } = await auth();
  const metadata = (sessionClaims?.metadata ?? {}) as { role?: string; department?: string };
  const role = normalizeRole(metadata.role);

  if (!userId || !can(role, permission)) {
    throw new Error("Forbidden: you do not have permission for this action");
  }

  return {
    userId,
    role,
    department: metadata.department?.trim() ? metadata.department.trim() : null,
  };
}

// Legacy alias kept for compatibility with any existing imports.
const requireAdmin = requirePermission.bind(null, PERMISSIONS.ROLE_MANAGE);

/**
 * Database handle for server actions. Prefers the service-role client so
 * admin CRUD bypasses RLS (the public schema grants no write policies to
 * anon/authenticated roles by design — access is enforced in this file via
 * requirePermission). Falls back to the session client when
 * SUPABASE_SERVICE_ROLE_KEY is not configured.
 */
async function dbClient() {
  return createAdminClient() ?? (await createClient());
}

function assertNotBot(formData: FormData) {
  const honeypot = formData.get("website");
  if (typeof honeypot === "string" && honeypot.trim().length > 0) {
    throw new Error("Submission rejected");
  }
}

// ---------------------------------------------------------------------------
// Validation schemas
// ---------------------------------------------------------------------------

const vulnerabilitySchema = z.object({
  title: z.string().min(5),
  severity: z.enum(["Critical", "High", "Medium", "Low"]),
  description: z.string().min(20),
  affected_asset: z.string().min(2),
});

const blogPostSchema = z.object({
  title: z.string().min(3),
  slug: z
    .string()
    .min(1)
    .regex(/^[a-z0-9]+(?:-[a-z0-9]+)*$/, "Slug must be lowercase, hyphen-separated"),
  category: z.enum(["Announcements", "Tutorials", "Research"]),
  content: z.string().min(10),
});

const writeupSchema = z.object({
  title: z.string().min(3),
  slug: z
    .string()
    .min(1)
    .regex(/^[a-z0-9]+(?:-[a-z0-9]+)*$/, "Slug must be lowercase, hyphen-separated"),
  challenge_name: z.string().min(2),
  difficulty: z.enum(["Beginner", "Intermediate", "Advanced"]),
  category: z.string().min(2),
  content: z.string().min(10),
});

const ctfModuleSchema = z.object({
  title: z.string().min(3),
  category: z.string().min(2),
  difficulty: z.enum(["Beginner", "Intermediate", "Advanced"]),
  content: z.string().min(10),
});

const teamMemberSchema = z.object({
  name: z.string().min(2),
  role: z.string().min(2),
  department: z.string().nullable().optional(),
  sort_order: z.coerce.number().int().min(0).default(0),
});

const applicationSchema = z.object({
  full_name: z.string().min(2),
  email: z.string().email(),
  department_interest: z.string().min(2),
  experience: z.string().min(10),
});

const contactSchema = z.object({
  name: z.string().min(2),
  email: z.string().email(),
  message: z.string().min(10),
});

const siteConfigSchema = z.object({
  members_count: z.coerce.number().int().min(0).default(0),
  ctfs_participated: z.coerce.number().int().min(0).default(0),
  writeups_published: z.coerce.number().int().min(0).default(0),
});

const APPLICATION_STATUSES = ["New", "Reviewing", "Accepted", "Rejected"] as const;

// ---------------------------------------------------------------------------
// Public forms — Phase 13 (rate limiting) + Phase 12 (notifications)
// ---------------------------------------------------------------------------

// ACTION: Submit Vulnerability Report
export async function submitVulnerabilityReport(formData: FormData) {
  const { userId, orgId } = await auth();
  if (!userId || !orgId) {
    throw new Error("Unauthorized: You must be logged in and in an organization");
  }

  const limited = await rateLimit({ route: "api/secure/vulnerability-reports", limit: 10 });
  if (!limited.ok) {
    throw new Error(
      `Rate limit exceeded. Please retry in ${limited.retryAfterSeconds ?? 60} seconds.`
    );
  }

  const parsed = vulnerabilitySchema.safeParse({
    title: formData.get("title"),
    severity: formData.get("severity"),
    description: formData.get("description"),
    affected_asset: formData.get("affected_asset"),
  });

  if (!parsed.success) {
    throw new Error("Invalid form data: " + parsed.error.message);
  }

  const supabase = await dbClient();
  const { data: inserted, error } = await supabase
    .from("vulnerability_reports")
    .insert({ ...parsed.data, org_id: orgId })
    .select("id")
    .single();

  if (error) {
    throw new Error("Database error: " + error.message);
  }

  // Phase 12: Critical/High reports page the org account lead immediately.
  if (parsed.data.severity === "Critical" || parsed.data.severity === "High") {
    await notifyAdmins({
      subject: `[${parsed.data.severity}] New vulnerability report — ${parsed.data.title}`,
      text: `A ${parsed.data.severity} vulnerability report was submitted by org ${orgId}.\n\nAsset: ${parsed.data.affected_asset}\n\n${parsed.data.description}`,
    });
  }

  await logAudit({
    actorId: userId,
    action: "submit_vulnerability_report",
    entity: "vulnerability_reports",
    entityId: inserted?.id,
    after: parsed.data,
  });

  revalidatePath("/portal/client");
  revalidatePath("/");
}

// ACTION: Submit Membership Application (/join)
export async function submitApplication(formData: FormData) {
  assertNotBot(formData);

  const limited = await rateLimit({ route: "/join", limit: 5, windowSeconds: 60 });
  if (!limited.ok) {
    throw new Error(
      `Too many submissions from this address. Please retry in ${limited.retryAfterSeconds ?? 60} seconds.`
    );
  }

  const parsed = applicationSchema.safeParse({
    full_name: formData.get("full_name"),
    email: formData.get("email"),
    department_interest: formData.get("department_interest"),
    experience: formData.get("experience"),
  });

  if (!parsed.success) {
    throw new Error("Invalid form data: " + parsed.error.message);
  }

  const supabase = await dbClient();
  const { error } = await supabase.from("applications").insert(parsed.data);
  if (error) throw new Error("Database error: " + error.message);

  await notifyAdmins({
    subject: "New membership application",
    text: `${parsed.data.full_name} (${parsed.data.email}) applied for ${parsed.data.department_interest}.\n\n${parsed.data.experience}`,
  });
}

// ACTION: Submit Contact Form Message (/contact)
export async function submitContactMessage(formData: FormData) {
  assertNotBot(formData);

  const limited = await rateLimit({ route: "/contact", limit: 5, windowSeconds: 60 });
  if (!limited.ok) {
    throw new Error(
      `Too many messages from this address. Please retry in ${limited.retryAfterSeconds ?? 60} seconds.`
    );
  }

  const parsed = contactSchema.safeParse({
    name: formData.get("name"),
    email: formData.get("email"),
    message: formData.get("message"),
  });

  if (!parsed.success) {
    throw new Error("Invalid form data: " + parsed.error.message);
  }

  const supabase = await dbClient();
  const { error } = await supabase.from("contact_messages").insert(parsed.data);
  if (error) throw new Error("Database error: " + error.message);

  await notifyAdmins({
    subject: "New contact message",
    text: `From ${parsed.data.name} (${parsed.data.email}):\n\n${parsed.data.message}`,
  });
}

// ---------------------------------------------------------------------------
// Blog posts — Phase 10 CRUD, gated by blog:write (Phase 11)
// ---------------------------------------------------------------------------

// ACTION: Create Blog Post
export async function createBlogPost(formData: FormData) {
  const { userId, role } = await requirePermission(PERMISSIONS.BLOG_WRITE);

  const parsed = blogPostSchema.safeParse({
    title: formData.get("title"),
    slug: formData.get("slug"),
    category: formData.get("category"),
    content: formData.get("content"),
  });

  if (!parsed.success) {
    throw new Error("Invalid form data: " + parsed.error.message);
  }

  const isPublished = formData.get("is_published") === "on";

  const supabase = await dbClient();
  const { data: inserted, error } = await supabase
    .from("blog_posts")
    .insert({ ...parsed.data, is_published: isPublished, author_id: userId })
    .select("id")
    .single();

  if (error) throw new Error("Database error: " + error.message);

  await logAudit({
    actorId: userId,
    actorRole: role,
    action: "create_blog_post",
    entity: "blog_posts",
    entityId: inserted?.id,
    after: { ...parsed.data, is_published: isPublished },
  });

  revalidatePath("/blog");
  revalidatePath("/");
}

// ACTION: Update Blog Post
export async function updateBlogPost(formData: FormData) {
  const { userId, role } = await requirePermission(PERMISSIONS.BLOG_WRITE);

  const id = str(formData, "id");
  if (!id) throw new Error("Missing post id");

  const parsed = blogPostSchema.safeParse({
    title: formData.get("title"),
    slug: formData.get("slug"),
    category: formData.get("category"),
    content: formData.get("content"),
  });

  if (!parsed.success) {
    throw new Error("Invalid form data: " + parsed.error.message);
  }

  const isPublished = formData.get("is_published") === "on";

  const supabase = await dbClient();
  const { data: existing, error: fetchError } = await supabase
    .from("blog_posts")
    .select("title, slug, category, content, is_published")
    .eq("id", id)
    .single();

  if (fetchError || !existing) throw new Error("Post not found");

  const { data: updated, error } = await supabase
    .from("blog_posts")
    .update({ ...parsed.data, is_published: isPublished })
    .eq("id", id)
    .select("id")
    .single();

  if (error) throw new Error("Database error: " + error.message);

  await logAudit({
    actorId: userId,
    actorRole: role,
    action: "update_blog_post",
    entity: "blog_posts",
    entityId: updated?.id,
    before: existing,
    after: { ...parsed.data, is_published: isPublished },
  });

  revalidatePath("/blog");
  revalidatePath(`/blog/${parsed.data.slug}`);
  revalidatePath("/");
}

// ACTION: Delete Blog Post
export async function deleteBlogPost(formData: FormData) {
  const { userId, role } = await requirePermission(PERMISSIONS.BLOG_WRITE);

  const id = str(formData, "id");
  if (!id) throw new Error("Missing post id");

  const supabase = await dbClient();
  const { data: existing, error: fetchError } = await supabase
    .from("blog_posts")
    .select("title, slug")
    .eq("id", id)
    .single();

  if (fetchError || !existing) throw new Error("Post not found");

  const { error } = await supabase.from("blog_posts").delete().eq("id", id);
  if (error) throw new Error("Database error: " + error.message);

  await logAudit({
    actorId: userId,
    actorRole: role,
    action: "delete_blog_post",
    entity: "blog_posts",
    entityId: id,
    before: existing,
  });

  revalidatePath("/blog");
  revalidatePath("/");
}

// ---------------------------------------------------------------------------
// Writeups — Phase 10 CRUD, gated by writeups:write, dept-scoped (Phase 11)
// ---------------------------------------------------------------------------

function departmentMatches(requesterDepartment: string | null, recordDepartment: string | null): boolean {
  const normalizedRequester = requesterDepartment?.trim().toLowerCase() ?? "";
  const normalizedRecord = recordDepartment?.trim().toLowerCase() ?? "";
  return normalizedRequester === normalizedRecord;
}

// ACTION: Create Writeup
export async function createWriteup(formData: FormData) {
  const { userId, role, department } = await requirePermission(PERMISSIONS.WRITEUPS_WRITE);

  const parsed = writeupSchema.safeParse({
    title: formData.get("title"),
    slug: formData.get("slug"),
    challenge_name: formData.get("challenge_name"),
    difficulty: formData.get("difficulty"),
    category: formData.get("category"),
    content: formData.get("content"),
  });

  if (!parsed.success) {
    throw new Error("Invalid form data: " + parsed.error.message);
  }

  const isGated = formData.get("is_gated") === "on";
  let writeupDepartment = strOrNull(formData, "department");

  if (role === "dept_lead") {
    // dept_lead can only create writeups in their own department.
    if (!departmentMatches(department, writeupDepartment)) {
      throw new Error("Forbidden: department leads can only create writeups in their own department");
    }
  }

  const supabase = await dbClient();
  const { data: inserted, error } = await supabase
    .from("writeups")
    .insert({
      ...parsed.data,
      is_gated: isGated,
      department: writeupDepartment,
    })
    .select("id")
    .single();

  if (error) throw new Error("Database error: " + error.message);

  await logAudit({
    actorId: userId,
    actorRole: role,
    action: "create_writeup",
    entity: "writeups",
    entityId: inserted?.id,
    after: { ...parsed.data, is_gated: isGated, department: writeupDepartment },
  });

  revalidatePath("/writeups");
  revalidatePath("/portal/learner");
}

// ACTION: Update Writeup
export async function updateWriteup(formData: FormData) {
  const { userId, role, department } = await requirePermission(PERMISSIONS.WRITEUPS_WRITE);

  const id = str(formData, "id");
  if (!id) throw new Error("Missing writeup id");

  const parsed = writeupSchema.safeParse({
    title: formData.get("title"),
    slug: formData.get("slug"),
    challenge_name: formData.get("challenge_name"),
    difficulty: formData.get("difficulty"),
    category: formData.get("category"),
    content: formData.get("content"),
  });

  if (!parsed.success) {
    throw new Error("Invalid form data: " + parsed.error.message);
  }

  const isGated = formData.get("is_gated") === "on";
  const writeupDepartment = strOrNull(formData, "department");

  const supabase = await dbClient();
  const { data: existing, error: fetchError } = await supabase
    .from("writeups")
    .select("title, slug, challenge_name, difficulty, category, content, is_gated, department")
    .eq("id", id)
    .single();

  if (fetchError || !existing) throw new Error("Writeup not found");

  if (role === "dept_lead" && !departmentMatches(department, existing.department)) {
    throw new Error("Forbidden: department leads can only manage writeups in their own department");
  }

  const { data: updated, error } = await supabase
    .from("writeups")
    .update({
      ...parsed.data,
      is_gated: isGated,
      department: writeupDepartment,
    })
    .eq("id", id)
    .select("id")
    .single();

  if (error) throw new Error("Database error: " + error.message);

  await logAudit({
    actorId: userId,
    actorRole: role,
    action: "update_writeup",
    entity: "writeups",
    entityId: updated?.id,
    before: existing,
    after: { ...parsed.data, is_gated: isGated, department: writeupDepartment },
  });

  revalidatePath("/writeups");
  revalidatePath("/writeups/" + parsed.data.slug);
  revalidatePath("/portal/learner");
}

// ACTION: Delete Writeup
export async function deleteWriteup(formData: FormData) {
  const { userId, role, department } = await requirePermission(PERMISSIONS.WRITEUPS_WRITE);

  const id = str(formData, "id");
  if (!id) throw new Error("Missing writeup id");

  const supabase = await dbClient();
  const { data: existing, error: fetchError } = await supabase
    .from("writeups")
    .select("title, slug, department")
    .eq("id", id)
    .single();

  if (fetchError || !existing) throw new Error("Writeup not found");

  if (role === "dept_lead" && !departmentMatches(department, existing.department)) {
    throw new Error("Forbidden: department leads can only manage writeups in their own department");
  }

  const { error } = await supabase.from("writeups").delete().eq("id", id);
  if (error) throw new Error("Database error: " + error.message);

  await logAudit({
    actorId: userId,
    actorRole: role,
    action: "delete_writeup",
    entity: "writeups",
    entityId: id,
    before: existing,
  });

  revalidatePath("/writeups");
  revalidatePath("/portal/learner");
}

// ---------------------------------------------------------------------------
// CTF modules — gated by ctf:write, dept-scoped (Phase 11)
// ---------------------------------------------------------------------------

// ACTION: Create CTF Module
export async function createCTFModule(formData: FormData) {
  const { userId, role, department } = await requirePermission(PERMISSIONS.CTF_WRITE);

  const parsed = ctfModuleSchema.safeParse({
    title: formData.get("title"),
    category: formData.get("category"),
    difficulty: formData.get("difficulty"),
    content: formData.get("content"),
  });

  if (!parsed.success) {
    throw new Error("Invalid form data: " + parsed.error.message);
  }

  const moduleDepartment = strOrNull(formData, "department");

  if (role === "dept_lead" && !departmentMatches(department, moduleDepartment)) {
    throw new Error("Forbidden: department leads can only create modules in their own department");
  }

  const supabase = await dbClient();
  const { data: inserted, error } = await supabase
    .from("ctf_modules")
    .insert({ ...parsed.data, department: moduleDepartment })
    .select("id")
    .single();

  if (error) throw new Error("Database error: " + error.message);

  await logAudit({
    actorId: userId,
    actorRole: role,
    action: "create_ctf_module",
    entity: "ctf_modules",
    entityId: inserted?.id,
    after: { ...parsed.data, department: moduleDepartment },
  });

  revalidatePath("/portal/learner");
}

// ACTION: Update CTF / Training Module
export async function updateCTFModule(formData: FormData) {
  const { userId, role, department } = await requirePermission(PERMISSIONS.CTF_WRITE);

  const id = str(formData, "id");
  if (!id) throw new Error("Missing module id");

  const parsed = ctfModuleSchema.safeParse({
    title: formData.get("title"),
    category: formData.get("category"),
    difficulty: formData.get("difficulty"),
    content: formData.get("content"),
  });

  if (!parsed.success) {
    throw new Error("Invalid form data: " + parsed.error.message);
  }

  const moduleDepartment = strOrNull(formData, "department");

  const supabase = await dbClient();
  const { data: existing, error: fetchError } = await supabase
    .from("ctf_modules")
    .select("title, category, difficulty, content, department")
    .eq("id", id)
    .single();

  if (fetchError || !existing) throw new Error("Module not found");

  if (role === "dept_lead" && !departmentMatches(department, existing.department)) {
    throw new Error("Forbidden: department leads can only manage modules in their own department");
  }

  const { data: updated, error } = await supabase
    .from("ctf_modules")
    .update({
      title: parsed.data.title,
      category: parsed.data.category,
      difficulty: parsed.data.difficulty,
      content: parsed.data.content,
      department: moduleDepartment,
    })
    .eq("id", id)
    .select("id")
    .single();

  if (error) throw new Error("Database error: " + error.message);

  await logAudit({
    actorId: userId,
    actorRole: role,
    action: "update_ctf_module",
    entity: "ctf_modules",
    entityId: updated?.id,
    before: existing,
    after: { ...parsed.data, department: moduleDepartment },
  });

  revalidatePath("/portal/learner");
}

// ACTION: Delete CTF Module
export async function deleteCTFModule(formData: FormData) {
  const { userId, role, department } = await requirePermission(PERMISSIONS.CTF_WRITE);

  const id = str(formData, "id");
  if (!id) throw new Error("Missing module id");

  const supabase = await dbClient();
  const { data: existing, error: fetchError } = await supabase
    .from("ctf_modules")
    .select("title, department")
    .eq("id", id)
    .single();

  if (fetchError || !existing) throw new Error("Module not found");

  if (role === "dept_lead" && !departmentMatches(department, existing.department)) {
    throw new Error("Forbidden: department leads can only manage modules in their own department");
  }

  const { error } = await supabase.from("ctf_modules").delete().eq("id", id);
  if (error) throw new Error("Database error: " + error.message);

  await logAudit({
    actorId: userId,
    actorRole: role,
    action: "delete_ctf_module",
    entity: "ctf_modules",
    entityId: id,
    before: existing,
  });

  revalidatePath("/portal/learner");
}

// ---------------------------------------------------------------------------
// Team members — Phase 10 CRUD, gated by team:write
// ---------------------------------------------------------------------------

// ACTION: Create or Update Team Member
export async function upsertTeamMember(formData: FormData) {
  const { userId, role } = await requirePermission(PERMISSIONS.TEAM_WRITE);

  const id = strOrNull(formData, "id");
  const parsed = teamMemberSchema.safeParse({
    name: formData.get("name"),
    role: formData.get("role"),
    department: strOrNull(formData, "department"),
    sort_order: formData.get("sort_order") ?? "0",
  });

  if (!parsed.success) {
    throw new Error("Invalid form data: " + parsed.error.message);
  }

  const supabase = await dbClient();

  if (id) {
    const { data: existing, error: fetchError } = await supabase
      .from("team_members")
      .select("name, role, department, sort_order")
      .eq("id", id)
      .single();

    if (fetchError || !existing) throw new Error("Team member not found");

    const { data: updated, error } = await supabase
      .from("team_members")
      .update(parsed.data)
      .eq("id", id)
      .select("id")
      .single();

    if (error) throw new Error("Database error: " + error.message);

    await logAudit({
      actorId: userId,
      actorRole: role,
      action: "update_team_member",
      entity: "team_members",
      entityId: updated?.id,
      before: existing,
      after: parsed.data,
    });
  } else {
    const { data: inserted, error } = await supabase
      .from("team_members")
      .insert(parsed.data)
      .select("id")
      .single();

    if (error) throw new Error("Database error: " + error.message);

    await logAudit({
      actorId: userId,
      actorRole: role,
      action: "create_team_member",
      entity: "team_members",
      entityId: inserted?.id,
      after: parsed.data,
    });
  }

  revalidatePath("/about");
}

// ACTION: Delete Team Member
export async function deleteTeamMember(formData: FormData) {
  const { userId, role } = await requirePermission(PERMISSIONS.TEAM_WRITE);

  const id = str(formData, "id");
  if (!id) throw new Error("Missing team member id");

  const supabase = await dbClient();
  const { data: existing, error: fetchError } = await supabase
    .from("team_members")
    .select("name, role")
    .eq("id", id)
    .single();

  if (fetchError || !existing) throw new Error("Team member not found");

  const { error } = await supabase.from("team_members").delete().eq("id", id);
  if (error) throw new Error("Database error: " + error.message);

  await logAudit({
    actorId: userId,
    actorRole: role,
    action: "delete_team_member",
    entity: "team_members",
    entityId: id,
    before: existing,
  });

  revalidatePath("/about");
}

// ---------------------------------------------------------------------------
// Applications inbox — Phase 10, gated by applications:manage
// ---------------------------------------------------------------------------

// ACTION: Update Application Status
export async function updateApplicationStatus(formData: FormData) {
  const { userId, role } = await requirePermission(PERMISSIONS.APPLICATIONS_MANAGE);

  const id = str(formData, "id");
  const status = str(formData, "status");

  if (!id) throw new Error("Missing application id");
  if (!APPLICATION_STATUSES.includes(status as (typeof APPLICATION_STATUSES)[number])) {
    throw new Error("Invalid status");
  }

  const supabase = await dbClient();
  const { data: existing, error: fetchError } = await supabase
    .from("applications")
    .select("status")
    .eq("id", id)
    .single();

  if (fetchError || !existing) throw new Error("Application not found");

  const { data: updated, error } = await supabase
    .from("applications")
    .update({ status })
    .eq("id", id)
    .select("id")
    .single();

  if (error) throw new Error("Database error: " + error.message);

  await logAudit({
    actorId: userId,
    actorRole: role,
    action: "update_application_status",
    entity: "applications",
    entityId: updated?.id,
    before: existing,
    after: { status },
  });

  revalidatePath("/admin/applications");
}

// ---------------------------------------------------------------------------
// Site stats — Phase 10, gated by site_config:write
// ---------------------------------------------------------------------------

// ACTION: Update Site Config
export async function updateSiteConfig(formData: FormData) {
  const { userId, role } = await requirePermission(PERMISSIONS.SITE_CONFIG_WRITE);

  const parsed = siteConfigSchema.safeParse({
    members_count: formData.get("members_count") ?? "0",
    ctfs_participated: formData.get("ctfs_participated") ?? "0",
    writeups_published: formData.get("writeups_published") ?? "0",
  });

  if (!parsed.success) {
    throw new Error("Invalid form data: " + parsed.error.message);
  }

  const supabase = await dbClient();
  const { data: existing, error: fetchError } = await supabase
    .from("site_config")
    .select("members_count, ctfs_participated, writeups_published")
    .eq("id", 1)
    .single();

  if (fetchError && fetchError.code !== "PGRST116") {
    throw new Error("Database error: " + fetchError.message);
  }

  const { error } = await supabase
    .from("site_config")
    .upsert({ id: 1, ...parsed.data })
    .eq("id", 1);

  if (error) throw new Error("Database error: " + error.message);

  await logAudit({
    actorId: userId,
    actorRole: role,
    action: "update_site_config",
    entity: "site_config",
    entityId: "1",
    before: existing ?? null,
    after: parsed.data,
  });

  revalidatePath("/");
  revalidatePath("/admin/site-stats");
}

// ---------------------------------------------------------------------------
// Audit report uploads — Phase 16, gated by reports:upload
// ---------------------------------------------------------------------------

// ACTION: Upload an audit PDF to a client org's private bucket
export async function uploadAuditReport(formData: FormData) {
  const { userId, role } = await requirePermission(PERMISSIONS.REPORTS_UPLOAD);

  const orgId = str(formData, "org_id").trim();
  const file = formData.get("file");

  if (!orgId) throw new Error("Client Org ID is required");
  if (!(file instanceof File)) throw new Error("A file is required");
  if (file.size === 0) throw new Error("File is empty");
  if (file.size > 10 * 1024 * 1024) throw new Error("File must be under 10 MB");
  if (!["application/pdf", "application/octet-stream"].includes(file.type) && !file.name.toLowerCase().endsWith(".pdf")) {
    throw new Error("Only PDF files are supported");
  }

  const filePath = `reports/${orgId}/${crypto.randomUUID()}.pdf`;
  const bytes = Buffer.from(await file.arrayBuffer());

  const client = createAdminClient() ?? (await createClient());
  const { error: uploadError } = await client.storage
    .from("audit-reports")
    .upload(filePath, bytes, {
      contentType: "application/pdf",
      upsert: false,
      metadata: { org_id: orgId },
    });

  if (uploadError) {
    throw new Error(
      "Storage error: " +
        uploadError.message +
        " (if you are uploading for a client org you are not a member of, configure SUPABASE_SERVICE_ROLE_KEY)"
    );
  }

  const { data: inserted, error: rowError } = await client
    .from("audit_reports")
    .insert({
      org_id: orgId,
      file_path: filePath,
      original_name: file.name,
      uploaded_by: userId,
    })
    .select("id")
    .single();

  if (rowError) {
    // Best-effort: don't leave an orphan object behind.
    await client.storage.from("audit-reports").remove([filePath]);
    throw new Error("Database error: " + rowError.message);
  }

  await logAudit({
    actorId: userId,
    actorRole: role,
    action: "upload_audit_report",
    entity: "audit_reports",
    entityId: inserted?.id,
    after: { org_id: orgId, original_name: file.name, file_path: filePath },
  });

  revalidatePath("/admin/reports");
  revalidatePath("/portal/client");
}

export { requireAdmin };
// =========================================================
// Phase 16 — Client Portal Depth (RESTORED — was missing from actions.ts)
// =========================================================

const MAX_REPORT_PDF_BYTES = 20 * 1024 * 1024; // 20MB

export async function updateVulnerabilityReportStatus(formData: FormData) {
  const { userId, role } = await requirePermission(PERMISSIONS.REPORTS_READ);
  const id = formData.get("id") as string;
  const status = formData.get("status") as string;
  if (!id || !["Open", "In Remediation", "Resolved"].includes(status)) {
    throw new Error("Invalid status update");
  }

  const supabase = createAdminClient();
  if (!supabase) throw new Error("Server misconfigured: SUPABASE_SERVICE_ROLE_KEY not set");

  const { data: existing } = await supabase
    .from("vulnerability_reports")
    .select("status")
    .eq("id", id)
    .single();

  const { error } = await supabase.from("vulnerability_reports").update({ status }).eq("id", id);
  if (error) throw new Error("Database error: " + error.message);

  await logAudit({
    actorId: userId,
    actorRole: role,
    action: "update_vulnerability_report_status",
    entity: "vulnerability_reports",
    entityId: id,
    before: existing,
    after: { status },
  });

  revalidatePath("/admin/vulnerabilities");
  revalidatePath("/portal/client");
}

export async function uploadVulnerabilityReportPdf(formData: FormData) {
  const { userId, role } = await requirePermission(PERMISSIONS.REPORTS_UPLOAD);
  const id = formData.get("id") as string;
  const file = formData.get("file") as File | null;
  if (!id) throw new Error("Missing report id");
  if (!file || file.size === 0) throw new Error("No file selected");
  if (file.type !== "application/pdf") throw new Error("Only PDF files are accepted");
  if (file.size > MAX_REPORT_PDF_BYTES) throw new Error("File too large (20MB max)");

  const supabase = createAdminClient();
  if (!supabase) throw new Error("Server misconfigured: SUPABASE_SERVICE_ROLE_KEY not set");

  const { data: report } = await supabase
    .from("vulnerability_reports")
    .select("org_id, report_path")
    .eq("id", id)
    .single();
  if (!report) throw new Error("Report not found");

  const path = `${report.org_id}/${id}.pdf`;

  // Storage RLS's SELECT policy (schema.sql) checks object metadata.org_id
  // against the downloading client's JWT org_id claim — set it here so
  // clients can actually read what they're scoped to.
  const { error: uploadError } = await supabase.storage.from("audit-reports").upload(path, file, {
    contentType: "application/pdf",
    upsert: true,
    metadata: { org_id: report.org_id },
  });
  if (uploadError) throw new Error("Storage error: " + uploadError.message);

  const { error: dbError } = await supabase
    .from("vulnerability_reports")
    .update({ report_path: path })
    .eq("id", id);
  if (dbError) throw new Error("Database error: " + dbError.message);

  await logAudit({
    actorId: userId,
    actorRole: role,
    action: "upload_vulnerability_report_pdf",
    entity: "vulnerability_reports",
    entityId: id,
    before: { report_path: report.report_path },
    after: { report_path: path },
  });

  revalidatePath("/admin/vulnerabilities");
  revalidatePath("/portal/client");
}

// =========================================================
// Phase 16 — Billing scaffold (Stripe) (RESTORED — was missing entirely)
// =========================================================

// Founder links a Clerk org to a Stripe customer. There's no automated
// customer-creation flow yet (that's a Clerk org.created webhook, not
// scoped here) — see docs/billing-stripe-scope.md for why and what's next.
export async function linkOrgStripeCustomer(formData: FormData) {
  const { userId, role } = await requirePermission(PERMISSIONS.ROLE_MANAGE);
  const orgId = formData.get("org_id") as string;
  const stripeCustomerId = formData.get("stripe_customer_id") as string;
  if (!orgId || !stripeCustomerId) throw new Error("Org ID and Stripe customer ID are required");

  const supabase = createAdminClient();
  if (!supabase) throw new Error("Server misconfigured: SUPABASE_SERVICE_ROLE_KEY not set");

  const { error } = await supabase
    .from("org_billing")
    .upsert({ org_id: orgId, stripe_customer_id: stripeCustomerId, updated_at: new Date().toISOString() });
  if (error) throw new Error("Database error: " + error.message);

  await logAudit({
    actorId: userId,
    actorRole: role,
    action: "link_org_billing_customer",
    entity: "org_billing",
    entityId: orgId,
    after: { stripe_customer_id: stripeCustomerId },
  });

  revalidatePath("/admin/billing");
}

// Any signed-in member of an org with billing configured can open Stripe's
// hosted billing portal for that org — this is the "clients manage their
// own billing" requirement from the plan. Redirects instead of returning a
// URL, since it's invoked directly from a <form action={...}>.
export async function createBillingPortalSession() {
  const { userId, orgId } = await auth();
  if (!userId || !orgId) throw new Error("Unauthorized: you must be signed in and in an organization");

  const supabase = createAdminClient();
  if (!supabase) throw new Error("Server misconfigured: SUPABASE_SERVICE_ROLE_KEY not set");

  const { data: billing } = await supabase
    .from("org_billing")
    .select("stripe_customer_id")
    .eq("org_id", orgId)
    .single();

  if (!billing?.stripe_customer_id) {
    throw new Error("Billing isn't set up for this organization yet — contact Royal Security.");
  }

  const stripe = getStripe();
  const appUrl = process.env.NEXT_PUBLIC_APP_URL ?? "http://localhost:3000";
  const session = await stripe.billingPortal.sessions.create({
    customer: billing.stripe_customer_id,
    return_url: `${appUrl}/portal/client`,
  });

  redirect(session.url);
}
export async function getReportDownloadUrl(reportId: string): Promise<string> {
  const { userId, orgId } = await auth();
  if (!userId || !orgId) {
    throw new Error("Unauthorized: you must be signed in and in an organization");
  }

  const supabase = await createClient();
  const { data: report, error } = await supabase
    .from("vulnerability_reports")
    .select("report_path")
    .eq("id", reportId)
    .single();

  if (error || !report?.report_path) {
    throw new Error("Report not found or no file has been uploaded yet");
  }

  const { data: signed, error: signError } = await supabase.storage
    .from("audit-reports")
    .createSignedUrl(report.report_path, 60);

  if (signError || !signed?.signedUrl) {
    throw new Error("Could not generate download link: " + (signError?.message ?? "unknown error"));
  }

  return signed.signedUrl;
}