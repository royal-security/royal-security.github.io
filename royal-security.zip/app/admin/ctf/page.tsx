import Link from "next/link";
import { createAdminClient } from "@/utils/supabase/admin";
import { deleteCTFModule } from "@/app/actions";
import { requirePermissionPage } from "@/lib/roles-page";
import { PERMISSIONS } from "@/lib/roles";

export const dynamic = "force-dynamic";

async function getModules(department: string | null) {
  const supabase = createAdminClient();
  if (!supabase) return [];
  let query = supabase
    .from("ctf_modules")
    .select("id, title, category, difficulty, department, created_at")
    .order("created_at", { ascending: false });
  if (department) query = query.eq("department", department);
  const { data } = await query;
  return data ?? [];
}

export default async function AdminCTFPage() {
  const claims = await requirePermissionPage(PERMISSIONS.CTF_WRITE);
  const modules = await getModules(claims.role === "dept_lead" ? claims.department : null);

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold">CTF Modules</h1>
        <Link
          href="/admin/ctf/new"
          className="px-4 py-2 bg-blue-600 hover:bg-blue-500 rounded font-semibold text-sm transition"
        >
          + New Module
        </Link>
      </div>

      <div className="rounded-lg border border-gray-800 overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-gray-900 text-gray-400">
            <tr>
              <th className="text-left p-3">Title</th>
              <th className="text-left p-3">Category</th>
              <th className="text-left p-3">Difficulty</th>
              <th className="text-left p-3">Department</th>
              <th className="text-right p-3">Actions</th>
            </tr>
          </thead>
          <tbody>
            {modules.map((m) => (
              <tr key={m.id} className="border-t border-gray-800">
                <td className="p-3">{m.title}</td>
                <td className="p-3 text-gray-400">{m.category}</td>
                <td className="p-3 text-gray-400">{m.difficulty}</td>
                <td className="p-3 text-gray-400">{m.department ?? "—"}</td>
                <td className="p-3 text-right space-x-3">
                  <Link href={`/admin/ctf/${m.id}`} className="text-blue-400 hover:underline">
                    Edit
                  </Link>
                  <form action={deleteCTFModule} className="inline">
                    <input type="hidden" name="id" value={m.id} />
                    <button type="submit" className="text-red-400 hover:underline">
                      Delete
                    </button>
                  </form>
                </td>
              </tr>
            ))}
            {modules.length === 0 && (
              <tr>
                <td colSpan={5} className="p-6 text-center text-gray-500">
                  No CTF modules yet.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
