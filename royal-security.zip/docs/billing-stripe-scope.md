# Billing (Stripe) — Scope & Setup

The plan called this "not scoped at all yet." This is the scoping, plus a
working scaffold for the parts that don't depend on business decisions only
your team can make (pricing, products, who gets billed how).

## What's built

- `org_billing` table (`org_id` → `stripe_customer_id` / subscription status).
- `utils/stripe.ts` — lazy Stripe client, fails clearly if unconfigured
  rather than crashing the app.
- `linkOrgStripeCustomer` — founder-only action, `/admin/billing` — pastes a
  Stripe customer ID onto a Clerk org.
- `createBillingPortalSession` — any signed-in org member can open Stripe's
  hosted billing portal for their org (the "clients manage their own
  billing" line from the plan). Renders as a "Manage Billing" button on
  `/portal/client`, only when that org has a linked customer.
- `/api/webhooks/stripe` — verifies the signature, updates
  `org_billing.subscription_status` on `customer.subscription.*` events.

## What's deliberately NOT built (needs your input first)

1. **Products/prices in Stripe.** What are you actually charging for —
   per-seat, flat retainer per engagement, usage-based? This determines the
   Checkout/subscription setup, and guessing at it would just produce fake
   line items. Create these in the Stripe Dashboard once decided.

2. **Automated customer creation.** Right now, linking an org to a Stripe
   customer is a manual step in `/admin/billing`. A `org.created` Clerk
   webhook that auto-creates the Stripe customer is straightforward to add
   once you know what data should transfer (org name, initial plan, a sales
   contact's email for the Stripe customer record, etc).

3. **Checkout / initial subscription flow.** The portal button opens the
   *billing portal* (for an existing customer to manage payment methods,
   view invoices, change/cancel a plan you've already put them on) — it does
   not sell a new subscription. That's a separate Stripe Checkout flow, and
   needs the price IDs from step 1 first.

4. **Free trials, proration, multi-seat logic** — same reasoning: business
   decisions, not implementation details.

## Required setup once you're ready

- `STRIPE_SECRET_KEY` — Stripe Dashboard → Developers → API keys.
- `STRIPE_WEBHOOK_SECRET` — Developers → Webhooks → add endpoint
  `https://<your-domain>/api/webhooks/stripe`, subscribe to at least
  `customer.subscription.created`, `.updated`, `.deleted`. Copy the signing
  secret it gives you.
- `NEXT_PUBLIC_APP_URL` — used as the billing portal's return URL
  (defaults to `http://localhost:3000` if unset — set this in production).
- Enable the **Customer Portal** in Stripe Dashboard → Settings → Billing →
  Customer portal (off by default on new accounts).
