import { createAdminClient } from "@/utils/supabase/admin";
import { upsertTeamMember } from "@/app/actions";
import { TeamMemberRow } from "@/components/admin/TeamMemberRow";
import { requirePermissionPage } from "@/lib/roles-page";
import { PERMISSIONS } from "@/lib/roles";

export const dynamic = "force-dynamic";

const inputClass = "p-2 rounded bg-gray-800 border border-gray-700 text-white w-full";

async function getTeamMembers() {
  const supabase = createAdminClient();
  if (!supabase) return [];
  const { data } = await supabase
    .from("team_members")
    .select("id, name, role, department, sort_order")
    .order("sort_order", { ascending: true });
  return data ?? [];
}

export default async function AdminTeamPage() {
  await requirePermissionPage(PERMISSIONS.TEAM_WRITE);
  const members = await getTeamMembers();

  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">Team</h1>

      <div className="mb-8 p-6 rounded-lg border border-gray-800 bg-gray-900/50">
        <h2 className="text-lg font-semibold mb-4 text-emerald-400">Add Team Member</h2>
        <form action={upsertTeamMember} className="grid grid-cols-2 gap-4">
          <input name="name" placeholder="Name" required className={inputClass} />
          <input name="role" placeholder="Role" required className={inputClass} />
          <input name="department" placeholder="Department (optional)" className={inputClass} />
          <input
            name="sort_order"
            type="number"
            placeholder="Sort order (for /about)"
            defaultValue={0}
            className={inputClass}
          />
          <button
            type="submit"
            className="col-span-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-500 rounded font-semibold transition w-fit"
          >
            Add
          </button>
        </form>
      </div>

      <div className="rounded-lg border border-gray-800 overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-gray-900 text-gray-400">
            <tr>
              <th className="text-left p-3">Name</th>
              <th className="text-left p-3">Role</th>
              <th className="text-left p-3">Department</th>
              <th className="text-left p-3">Sort Order</th>
              <th className="text-right p-3">Actions</th>
            </tr>
          </thead>
          <tbody>
            {members.map((m) => (
              <TeamMemberRow key={m.id} member={m} />
            ))}
            {members.length === 0 && (
              <tr>
                <td colSpan={5} className="p-6 text-center text-gray-500">
                  No team members yet.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
      <p className="text-xs text-gray-500 mt-3">
        Sort order controls left-to-right / top-to-bottom placement in the /about org chart.
        Drag-to-reorder is a nice-to-have — for now, edit the number directly.
      </p>
    </div>
  );
}
